-- ============================================================================
-- TrueFP Bodycam: ядро (камера на голове, тело, настройки)
-- ============================================================================
TFPBC = TFPBC or {}
local TFPBC = TFPBC

-- ---------------------------------------------------------------- настройки
local cv = {}
TFPBC.CoreDefaults = {}
local function CV(name, default, help, noreset)
    cv[name] = CreateClientConVar("truefp_" .. name, tostring(default), true, false, help)
    if not noreset then TFPBC.CoreDefaults[name] = default end
end
-- Базовые значения = настройки автора (одинаковые у всех пользователей)
CV("enable", 1, "Включить камеру на голове")
CV("fov", 102, "Глобальный FOV камеры (0 = использовать стандартный)")
CV("cam_x", 0.2, "Смещение камеры вправо относительно головы")
CV("cam_y", 7.2, "Смещение камеры вперёд относительно головы")
CV("cam_z", 2.7, "Смещение камеры вверх относительно головы")
CV("cam_smooth", 30, "Сглаживание позиции головы (0 = выкл)")
CV("znear", 1, "Ближняя плоскость отсечения камеры")
CV("hide_head", 1, "Прятать голову (чтобы камера не упиралась в лицо)")
CV("static_body", 0, "Статичная поза тела: без анимации ходьбы и дыхания")
CV("body_lock", 1, "Тело всегда повёрнуто туда же, куда смотрит камера")
CV("nobob", 0, "Отключить качание оружия ARC9 при ходьбе")
CV("weapon_spread", 0.5, "Разнос оружия от центра экрана в положении от бедра (компенсация FOV)")

-- смещения рук (hip)
CV("wm_x", -2.55, "Смещение рук (WM) влево/вправо")
CV("wm_y", -1.9, "Смещение рук (WM) вперёд/назад")
CV("wm_z", -2.6, "Смещение рук (WM) вверх/вниз")
CV("wm_run_z", -0.04, "Смещение рук (WM) вверх/вниз при беге")

CV("rt_enable", 1, "Рендер оптики ARC9 с увеличением")
CV("rt_expensive", 1, "Оптика: всегда реальное увеличение (дороже по FPS)")
CV("holo_scale", 5, "Масштаб сетки коллиматоров")
CV("holo_native", 1, "Коллиматоры: 1 = рисовать штатным DoHolosight ARC9")
CV("tpik_fix", 1, "Руки без отставания от оружия (синхронизация TPIK ARC9)")
CV("debug", 0, "1 = раз в секунду печатать отладку в консоль", true)
CV("cfgver", 1, "служебное", true)
TFPBC.CV = cv

-- ---------------------------------------------------------------- хелперы
function TFPBC.SmoothAlpha(speed, dt)
    if not speed or speed <= 0 then return 1 end
    return 1 - math.exp(-speed * dt)
end

function TFPBC.AdaptiveLerpVec(cur, target, speed, dt, knee)
    local e = cur:Distance(target)
    local sp = speed * (1 + (e / knee) ^ 2)
    return LerpVector(TFPBC.SmoothAlpha(sp, dt), cur, target)
end

-- движения оружия считаются и показываются, даже когда игрок смотрит через камеру или открыто меню кастомизации
function TFPBC.MotionAllowed()
    if not cv.enable:GetBool() then return false end
    local ply = LocalPlayer()
    if not IsValid(ply) or not ply:Alive() then return false end
    if ply:InVehicle() or ply:GetObserverMode() ~= OBS_MODE_NONE then return false end
    return true
end

local activeFrame, activeVal = -1, false
function TFPBC.IsActive()
    local f = FrameNumber()
    if f == activeFrame then return activeVal end
    activeFrame = f
    activeVal = false
    if not cv.enable:GetBool() then return false end
    local ply = LocalPlayer()
    if not IsValid(ply) or not ply:Alive() then return false end
    if ply:InVehicle() or ply:GetObserverMode() ~= OBS_MODE_NONE then return false end
    if GetViewEntity() ~= ply then return false end
    local wpn = ply:GetActiveWeapon()
    if IsValid(wpn) and wpn.ARC9 and wpn.GetCustomize and wpn:GetCustomize() then return false end
    activeVal = true
    return true
end

-- ---------------------------------------------------------------- камера
local camRel

hook.Add("CalcView", "TFPBC_CalcView", function(ply, origin, angles, fov, znear, zfar)
    if not TFPBC.IsActive() then camRel = nil return end
    local dt = math.Clamp(RealFrameTime(), 0.001, 0.1)

    local userFov = cv.fov:GetFloat()
    if userFov > 0 then fov = userFov end

    local pos = origin
    local head = ply:LookupBone("ValveBiped.Bip01_Head1")
    if head then
        local m = ply:GetBoneMatrix(head)
        if m then
            local hp = m:GetTranslation()
            if hp:DistToSqr(origin) < 70 * 70 then pos = hp end
        end
    end

    local smooth = cv.cam_smooth:GetFloat()
    if smooth > 0 then
        local rel = ply:WorldToLocal(pos)
        if not camRel or camRel:DistToSqr(rel) > 1600 then
            camRel = Vector(rel.x, rel.y, rel.z)
        else
            camRel = TFPBC.AdaptiveLerpVec(camRel, rel, smooth, dt, 4)
        end
        pos = ply:LocalToWorld(camRel)
    else
        camRel = nil
    end

    pos = pos + angles:Forward() * cv.cam_y:GetFloat()
              + angles:Right() * cv.cam_x:GetFloat()
              + angles:Up() * cv.cam_z:GetFloat()

    -- степень прицеливания: 0 = от бедра, 1 = ADS
    local wpn = ply:GetActiveWeapon()
    local sa = 0
    if IsValid(wpn) then
        if wpn.ARC9 and wpn.GetSightAmount then
            sa = math.Clamp(wpn:GetSightAmount() or 0, 0, 1)
        elseif ply:KeyDown(IN_ATTACK2) then
            sa = 1
        end
    end

    -- движение: свэй, шаги, эффекты камеры, freelook, зум ADS (cl_motion.lua)
    local M = TFPBC.Motion
    local fx = M and M.Update(ply, dt, angles, sa, wpn) or nil
    TFPBC.LastFx = fx

    local camPos, camAng = pos, angles
    local refPos, refAng = pos, angles   -- от этой точки считается поза оружия
    if fx then
        local function ToWorld(v, a) return a:Forward() * v.x - a:Right() * v.y + a:Up() * v.z end
        local posOff = ToWorld(fx.cam.pos, angles)
        local f = fx.follow
        -- камера получает тряску целиком и freelook; оружие - только часть тряски и без freelook
        camPos = pos + posOff
        camAng = Angle(
            math.Clamp(angles.p + fx.cam.ang.p + fx.freelook.pitch, -89, 89),
            angles.y + fx.cam.ang.y + fx.freelook.yaw,
            angles.r + fx.cam.ang.r + fx.freelook.roll + fx.headRoll)
        refPos = pos + posOff * f
        refAng = Angle(angles.p + fx.cam.ang.p * f, angles.y + fx.cam.ang.y * f, angles.r + fx.cam.ang.r * f + fx.headRoll)

        -- ОПТИКА (по желанию): часть движения оружия можно перенести на камеру.
        -- По умолчанию 0: оружие качается само, как и от бедра, а картинка прицела идёт за ним.
        fx.wk = 1
        local oc = math.Clamp(cv.optic_cam_motion and cv.optic_cam_motion:GetFloat() or 0, 0, 1)
        if oc > 0 and sa > 0.05 and M.IsOpticScope and M.IsOpticScope(wpn) and fx.wpn then
            local w = fx.wpn
            local ko = sa * oc
            local ang = Angle((w.ang.p + w.stock.p + w.muz.p) * ko, (w.ang.y + w.stock.y + w.muz.y) * ko, w.axisRoll * ko)
            camAng = Angle(math.Clamp(camAng.p + ang.p, -89, 89), camAng.y + ang.y, camAng.r + ang.r)
            refAng = Angle(refAng.p + ang.p, refAng.y + ang.y, refAng.r + ang.r)
            fx.wk = 1 - ko
        end
        fov = fov / fx.zoom
    end

    if IsValid(wpn) and wpn.ARC9 and TFPBC.OnWeaponFrame then
        fov = TFPBC.OnWeaponFrame(wpn, refPos, refAng, fov, fx)
    end

    return {
        origin = camPos,
        angles = camAng,
        fov = fov,
        znear = cv.znear:GetFloat(),
        zfar = zfar,
        drawviewer = true,
    }
end)

hook.Add("ShouldDrawLocalPlayer", "TFPBC_ShouldDraw", function()
    if not TFPBC.IsActive() then return end
    if ARC9 and ARC9.OverDraw then return false end
    return true
end)

hook.Add("PreDrawViewModel", "TFPBC_HideVM", function()
    if TFPBC.IsActive() then return true end
end)

-- ---------------------------------------------------------------- тело
local headHidden = false

local function ApplyHeadHidden(ply, hide)
    local b = ply:LookupBone("ValveBiped.Bip01_Head1")
    if not b then return end
    local cur = ply:GetManipulateBoneScale(b)
    local isHidden = cur.x < 0.5
    if hide and not isHidden then
        ply:ManipulateBoneScale(b, Vector(0.01, 0.01, 0.01))
    elseif not hide and isHidden then
        ply:ManipulateBoneScale(b, Vector(1, 1, 1))
    end
    headHidden = hide
end

hook.Add("PreRender", "TFPBC_Body", function()
    local ply = LocalPlayer()
    if not IsValid(ply) then return end
    local active = TFPBC.IsActive()
    if active then
        ApplyHeadHidden(ply, cv.hide_head:GetBool())
    elseif headHidden then
        ApplyHeadHidden(ply, false)
    end
    if not active then
        if TFPBC.OnInactive then TFPBC.OnInactive(ply) end
        return
    end

    if cv.static_body:GetBool() and ply:IsOnGround() and ply:GetMoveType() == MOVETYPE_WALK then
        ply:SetCycle(0)
    end
    if cv.body_lock:GetBool() then
        ply:SetRenderAngles(Angle(0, ply:EyeAngles().y, 0))
        ply:SetPoseParameter("aim_yaw", 0)
        ply:SetPoseParameter("body_yaw", 0)
        ply:SetPoseParameter("head_yaw", 0)
    end
    ply:InvalidateBoneCache()
end)

hook.Add("CalcMainActivity", "TFPBC_StaticActivity", function(ply)
    if ply ~= LocalPlayer() then return end
    if not cv.static_body:GetBool() or not TFPBC.IsActive() then return end
    if not ply:IsOnGround() or ply:GetMoveType() ~= MOVETYPE_WALK or ply:WaterLevel() >= 2 then return end
    ply.CalcIdeal = ply:Crouching() and ACT_MP_CROUCH_IDLE or ACT_MP_STAND_IDLE
    ply.CalcSeqOverride = -1
    return ply.CalcIdeal, ply.CalcSeqOverride
end)

concommand.Add("truefp_toggle", function()
    RunConsoleCommand("truefp_enable", cv.enable:GetBool() and "0" or "1")
end)

-- пока полный режим (камера на голове) не активен, но игрок жив (например, смотрит через камеру),
-- движения оружия всё равно считаются: их видно на своём теле и они уходят другим игрокам
hook.Add("Think", "TFPBC_IdleMotion", function()
    local M = TFPBC.Motion
    if not M or TFPBC.IsActive() or not TFPBC.MotionAllowed() then return end
    local ply = LocalPlayer()
    local wpn = ply:GetActiveWeapon()
    local sa = 0
    if IsValid(wpn) and wpn.ARC9 and wpn.GetSightAmount then sa = math.Clamp(wpn:GetSightAmount() or 0, 0, 1) end
    TFPBC.LastFx = M.Update(ply, math.Clamp(FrameTime(), 0.001, 0.1), ply:EyeAngles(), sa, wpn)
end)
