-- ============================================================================
-- Меню: Q -> Utilities -> TrueFP
--   Bodycam   : FOV, FOV в прицеле и переключатели функций (галочки)
--   Viewmodel : положение рук XYZ, freeaim, сила свэя, сила эффектов камеры, эффекты, аддон
-- Все числовые настройки спрятаны и имеют базовые значения (одинаковые у всех).
-- ============================================================================
local function Group(p, title, items)
    p:Help(title)
    for _, it in ipairs(items) do
        p:CheckBox(it[1], it[2])
    end
end

hook.Add("PopulateToolMenu", "TFPBC_Menu", function()
    -- ------------------------------------------------------------ Bodycam
    spawnmenu.AddToolMenuOption("Utilities", "TrueFP", "truefp_bodycam", "Bodycam", "", "", function(p)
        p:ClearControls()
        p:CheckBox("Включить аддон", "truefp_enable")
        p:NumSlider("FOV (0 = стандартный)", "truefp_fov", 0, 130, 0)
        p:NumSlider("FOV в прицеле (множитель зума)", "truefp_ads_zoom", 0.8, 3, 2)

        Group(p, "Тело и руки", {
            { "Прятать голову", "truefp_hide_head" },
            { "Статичная поза тела (без анимации ходьбы и дыхания)", "truefp_static_body" },
            { "Тело повёрнуто по взгляду", "truefp_body_lock" },
            { "Руки без отставания от оружия (TPIK)", "truefp_tpik_fix" },
            { "Отключить качание оружия ARC9 при ходьбе", "truefp_nobob" },
        })
        Group(p, "Свэй и движение оружия", {
            { "Свэй от мыши (инерция)", "truefp_f_sway" },
            { "Freeaim (только от бедра)", "truefp_freeaim_enable" },
            { "Резкие повороты (оружие отстаёт)", "truefp_whip_enable" },
            { "Качание при ходьбе (приклад и дуло)", "truefp_walk_enable" },
            { "Тремор рук", "truefp_f_tremor" },
            { "Бег (roll)", "truefp_f_sprint" },
            { "Наклон при движении (завал, pivot roll, разгон, прыжок)", "truefp_f_lean" },
            { "Дыхание", "truefp_f_breath" },
        })
        Group(p, "Камера", {
            { "Тряска при шагах", "truefp_f_stepshake" },
            { "Покачивание и крен камеры", "truefp_f_camroll" },
        })
        Group(p, "Отдача и усталость", {
            { "Анимированная отдача", "truefp_recoil_enable" },
            { "Усталость рук в прицеле", "truefp_fatigue_enable" },
            { "Low ready (опускание оружия при бездействии)", "truefp_lowready_enable" },
        })
        Group(p, "Freelook и перезарядка", {
            { "Freelook", "truefp_freelook_enable" },
            { "Взгляд вниз при перезарядке", "truefp_reload_head_enable" },
        })
        local binder = vgui.Create("DBinder")
        binder:SetValue(TFPBC.CV.freelook_key:GetInt())
        binder.OnChange = function(_, num) RunConsoleCommand("truefp_freelook_key", tostring(num)) end
        p:Help("Клавиша freelook (по умолчанию Alt):")
        p:AddItem(binder)

        Group(p, "Оптика ARC9", {
            { "Рендер оптики с увеличением", "truefp_rt_enable" },
            { "Оптика: всегда реальное увеличение (дороже по FPS)", "truefp_rt_expensive" },
            { "Коллиматоры: штатный DoHolosight ARC9", "truefp_holo_native" },
        })
        Group(p, "Сеть и сервер", {
            { "Показывать мои движения другим игрокам", "truefp_net_send" },
            { "Показывать движения других игроков", "truefp_net_receive" },
            { "Траектория из дула (True Aim)", "arc9_muzzle_laser_enable" },
            { "Contact IK: отмена при перезарядке и отвороте, TPIK пропускает руку", "truefp_f_cik" },
            { "Свои скорость, инерция и пауза прыжка (нужно разрешение сервера)", "truefp_move_enable" },
        })

        p:Help("Прочее")
        local reset = vgui.Create("DButton")
        reset:SetText("Сбросить всё к базовым значениям")
        reset.DoClick = function() if TFPBC.Motion then TFPBC.Motion.ResetDefaults() end end
        p:AddItem(reset)
        p:CheckBox("Печатать отладку в консоль", "truefp_debug")
    end)

    -- ------------------------------------------------------------ Viewmodel
    spawnmenu.AddToolMenuOption("Utilities", "TrueFP", "truefp_viewmodel", "Viewmodel", "", "", function(p)
        p:ClearControls()
        p:Help("Положение рук (WM) — сбрасывается к 0 в прицеле")
        p:NumSlider("Руки: X (влево/вправо)", "truefp_wm_x", -10, 10, 2)
        p:NumSlider("Руки: Y (вперёд/назад)", "truefp_wm_y", -10, 10, 2)
        p:NumSlider("Руки: Z (вверх/вниз)", "truefp_wm_z", -10, 10, 2)
        p:NumSlider("Руки при беге: Z (вверх/вниз)", "truefp_wm_run_z", -10, 10, 2)

        p:Help("Эффекты")
        p:NumSlider("Сила свэя", "truefp_weapon_motion", 0, 3, 2)
        p:NumSlider("Сила эффектов камеры", "truefp_camera_motion", 0, 3, 2)
        p:CheckBox("Включить freeaim", "truefp_freeaim_enable")
        p:CheckBox("Включить эффекты (свэй и камера)", "truefp_motion_enable")
        p:CheckBox("Включить аддон", "truefp_enable")
    end)
end)
