-- ============================================================================
-- TrueFP Bodycam: синхронизация движений оружия с другими игроками
-- Свой свэй, отдача, low ready, шаги и т.д. отправляются на сервер (12 чисел, ~20 раз/сек) и
-- применяются к позе worldmodel чужого игрока. Руки подтягивает TPIK ARC9 уже к этой позе.
-- ============================================================================
local TFPBC = TFPBC
local cv = TFPBC.CV
local M = TFPBC.Motion
TFPBC.Remote = TFPBC.Remote or {}

-- ---------------------------------------------------------------- отправка
local sendNext, sending = 0, false

hook.Add("Think", "TFPBC_NetSend", function()
    if CurTime() < sendNext then return end
    sendNext = CurTime() + 1 / math.max(cv.net_rate:GetFloat(), 1)
    local ply = LocalPlayer()
    if not IsValid(ply) then return end
    local wpn = ply:GetActiveWeapon()
    local fx = TFPBC.LastFx
    local want = cv.net_send:GetBool() and TFPBC.MotionAllowed() and fx and fx.wpn and IsValid(wpn) and wpn.ARC9
    if want then
        local v = M.ExportWeapon(fx.wpn)
        net.Start("TFPBC_Motion", true)
        net.WriteBool(true)
        for i = 1, 12 do net.WriteInt(math.Clamp(math.Round(v[i] * 100), -32000, 32000), 16) end
        net.SendToServer()
        sending = true
    elseif sending then
        net.Start("TFPBC_Motion", true)
        net.WriteBool(false)
        net.SendToServer()
        sending = false
    end
end)

-- ---------------------------------------------------------------- приём
net.Receive("TFPBC_Motion", function()
    local idx = net.ReadUInt(8)
    local on = net.ReadBool()
    local R = TFPBC.Remote[idx]
    local fresh = false
    if not R then R = M.NewRemoteState(); TFPBC.Remote[idx] = R; fresh = true end
    if on and not R.on then fresh = true end
    R.on, R.t = on, CurTime()
    for i = 1, 12 do
        local v = on and (net.ReadInt(16) / 100) or 0
        R.target[i] = v
        if fresh then R.cur[i] = v end
    end
end)

-- поза оружия чужого игрока: штатная (p, a) + присланные движения
function TFPBC.RemoteWeaponPose(owner, p, a)
    if not cv.net_receive:GetBool() then return end
    local R = TFPBC.Remote[owner:EntIndex()]
    if not R then return end
    local age = CurTime() - R.t
    if R.on and age > 0.7 then
        -- пакеты перестали приходить: плавно возвращаем в исходную позу
        for i = 1, 12 do R.target[i] = 0 end
    elseif not R.on and age > 1.5 then
        return
    end
    local w = M.UpdateRemote(R, math.Clamp(RealFrameTime(), 0.001, 0.1))
    local eye, ang = owner:EyePos(), owner:EyeAngles()
    local lp, la = WorldToLocal(p, a, eye, ang)
    lp, la = M.ApplyWeapon(lp, la, w)
    return LocalToWorld(lp, la, eye, ang)
end

-- свой игрок виден со стороны (камера, зеркало, третье лицо): штатная поза + свои движения
function TFPBC.LocalThirdPose(owner, p, a)
    if TFPBC.IsActive() then return end
    local fx = TFPBC.LastFx
    if not fx or not fx.wpn then return end
    local eye, ang = owner:EyePos(), owner:EyeAngles()
    local lp, la = WorldToLocal(p, a, eye, ang)
    lp, la = M.ApplyWeapon(lp, la, fx.wpn)
    return LocalToWorld(lp, la, eye, ang)
end

-- оружие чужих игроков нужно «пропатчить», чтобы поза учитывала присланные движения
timer.Create("TFPBC_PatchRemote", 0.5, 0, function()
    if not TFPBC.PatchWeapon then return end
    for _, ply in ipairs(player.GetAll()) do
        local w = ply:GetActiveWeapon()
        if IsValid(w) and w.ARC9 then TFPBC.PatchWeapon(w) end
    end
end)
