-- ============================================================================
-- TrueFP Bodycam: совместимость с Contact IK (руки и ноги по контакту с миром)
--  - TPIK (ARC9) пропускает левую руку, пока она в контакте
--  - контакт отменяется при перезарядке, осмотре, кастомизации
--  - контакт отменяется, если игрок отвернулся от объекта (удерживаемого или у стены)
-- ============================================================================
local TFPBC = TFPBC
local cv = TFPBC.CV

-- ---------------------------------------------------------------- отвернулся от объекта
local away = setmetatable({}, { __mode = "k" })   -- запомненные точки: гистерезис без мерцания

local function ContactPoints(ent, K)
    local held = K.NativeCarriedEntity and K.NativeCarriedEntity(ent)
    if IsValid(held) then return { held:WorldSpaceCenter() } end
    local rep = K.PassiveReports and K.PassiveReports[ent]
    if not rep or not rep.contacts then return nil end
    local pts = {}
    for _, c in pairs(rep.contacts) do
        if c.point then pts[#pts + 1] = Vector(c.point.x, c.point.y, c.point.z) end
    end
    return #pts > 0 and pts or nil
end

local function Faces(pts, ent, cosLimit)
    local eye, fwd = ent:EyePos(), ent:EyeAngles():Forward()
    for _, p in ipairs(pts) do
        local d = p - eye
        if d:LengthSqr() > 1 then
            d:Normalize()
            if d:Dot(fwd) < cosLimit then return false end
        end
    end
    return true
end

local function TurnedAway(ent, K)
    local limit = math.cos(math.rad(cv.cik_turn_limit:GetFloat()))
    local st = away[ent]
    if st then
        -- вернулся лицом к объекту (с запасом) - снова можно
        if Faces(st, ent, limit + 0.15) then away[ent] = nil return false end
        return true
    end
    local pts = ContactPoints(ent, K)
    if pts and not Faces(pts, ent, limit) then
        away[ent] = pts
        return true
    end
    return false
end

-- ---------------------------------------------------------------- подключение к Contact IK
local function Install()
    local K = ContactIK
    if not K or not K.PassiveEligibility or K.TFP_Wrapped then return end
    K.TFP_Wrapped = true
    local orig = K.PassiveEligibility
    K.PassiveEligibility = function(ent, fading)
        local allowed = orig(ent, fading)
        if not allowed then return nil end
        if IsValid(ent) and ent:IsPlayer() then
            local w = ent:GetActiveWeapon()
            if cv.f_cik:GetBool() and IsValid(w) and w.ARC9 then
                if (w.GetReloading and w:GetReloading()) or (w.GetInspecting and w:GetInspecting())
                    or (w.GetCustomize and w:GetCustomize()) then
                    away[ent] = nil
                    return nil
                end
            end
            if cv.f_cik:GetBool() and TurnedAway(ent, K) then return nil end
        end
        return allowed
    end
end

hook.Add("ContactIKReady", "TFPBC_ContactIK", Install)
Install()
timer.Simple(3, Install)

-- ---------------------------------------------------------------- TPIK пропускает руку в контакте
function TFPBC.ContactTPIKSkip(ply)
    if not IsValid(ply) then return end
    local wpn = ply:GetActiveWeapon()
    if not IsValid(wpn) or not wpn.ARC9 then return end
    local K = ContactIK
    local on = false
    if cv.f_cik:GetBool() and K and K.PassiveReports then
        local rep = K.PassiveReports[ply]
        local c = rep and rep.contacts and rep.contacts[1]   -- 1 = левая рука
        if c and (c.weight or 1) > 0.02 then on = true end
    end
    local cur = wpn.ARC9_TPIKTemporaryIKOverride
    if on then
        wpn.ARC9_TPIKTemporaryIKOverride = { suppressLeftHand = true, expires = CurTime() + 0.15, tfp = true }
    elseif cur and cur.tfp then
        wpn.ARC9_TPIKTemporaryIKOverride = nil
    end
end
