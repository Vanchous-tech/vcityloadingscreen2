-- ============================================================================
-- TrueFP Bodycam: движение (свэй оружия, freeaim, шаги, эффекты камеры, freelook, зум ADS)
-- Всё на пружинах (затухающие колебания), не зависит от FPS. Все параметры - в настройках.
-- ============================================================================
TFPBC = TFPBC or {}
local TFPBC = TFPBC
TFPBC.CV = TFPBC.CV or {}
local cv = TFPBC.CV

local M = {}
TFPBC.Motion = M

-- ---------------------------------------------------------------- реестр настроек
-- Базовые значения = настройки автора (одинаковые у всех пользователей)
local SD = {
    weapon_motion = 0.89,
    camera_motion = 0.98,
    sway_mouse = 0.5,
    sway_mouse_pitch = 3.0,
    sway_mouse_yaw = 3.0,
    sway_mouse_roll = 2.51,
    sway_speed = 7.8,
    sway_bounce = 0.38,
    sway_max = 15,
    freeaim_gain = 0.96,
    freeaim_yaw_limit = 11.7,
    freeaim_pitch_limit = 1.2,
    freeaim_return = 0,
    freeaim_roll = 0.58,
    freeaim_smooth = 6,
    freeaim_ads_return = 9.6,
    whip_threshold = 155,
    whip_strength = 0.74,
    whip_max = 180,
    whip_return = 6.9,
    whip_roll = 0.5,
    whip_ads_mult = 1.0,
    whip_pivot_fwd = -5,
    whip_pivot_up = 4,
    walk_pitch = 0.88,
    walk_yaw = 1.84,
    walk_roll = 4.7,
    walk_pos_x = 3.0,
    walk_pos_z = 0.35,
    walk_stock_amp = 0.96,
    walk_muzzle_amp = 2.15,
    walk_muzzle_phase = 180,
    stock_dist = 31,
    muzzle_dist = 21,
    step_stride = 40,
    tremor_amp = 0.0,
    tremor_speed = 0.3,
    tremor_walk_mult = 1.4,
    sprint_roll = 7.4,
    sprint_roll_base = -8.1,
    sprint_walk_keep = 1.0,
    sprint_blend_speed = 13.6,
    strafe_lean = 15,
    strafe_lean_speed = 16.3,
    pivot_roll = 15,
    pivot_speed = 19.8,
    accel_pitch = 2.64,
    air_pitch = 10,
    land_weapon = 3.0,
    pivot_fwd = 0,
    pivot_up = 2,
    pivot_left = 1,
    ads_sway_mult = 0.84,
    ads_walk_mult = 0.25,
    ads_speed_mult = 1.11,
    ads_zoom = 1.0,
    ads_zoom_speed = 5.4,
    optic_cam_motion = 0,
    cam_follow = 0,
    cam_follow_ads = 0,
    step_shake = 0.58,
    step_pitch = 0.96,
    step_roll = 0.82,
    step_yaw = 0.32,
    step_z = 0.25,
    step_sprint_mult = 1.14,
    step_ads_mult = 1.0,
    step_speed = 40,
    step_bounce = 0.15,
    bob_z = 0,
    bob_x = 0,
    bob_roll = 0.53,
    cam_strafe_roll = 10,
    cam_turn_roll = 0.12,
    cam_roll_ads_mult = 0.6,
    ads_head_roll = 4.0,
    land_cam = 3.0,
    jump_cam = 3.0,
    breath_amp = 0.41,
    breath_speed = 0.99,
    recoil_pitch = 0.28,
    recoil_yaw = 0,
    recoil_roll = 2.6,
    recoil_back = 0,
    recoil_recover = 2.7,
    recoil_bounce = 0.23,
    recoil_drift = 0,
    recoil_climb = 0.06,
    recoil_climb_max = 1,
    recoil_climb_decay = 2.8,
    recoil_heat = 0.03,
    recoil_heat_decay = 0.66,
    recoil_sway_mult = 0,
    recoil_wander = 0,
    recoil_ads_mult = 1.0,
    fatigue_time = 40,
    fatigue_recover = 3,
    fatigue_tremor = 8.5,
    fatigue_wander = 1.04,
    fatigue_camera = 0.39,
    lowready_delay = 60,
    lowready_pitch = 5,
    lowready_speed = 15,
    lowready_block_threshold = 0.82,
    mv_walk = 66,
    mv_run = 175,
    mv_inertia = 0.1,
    mv_jumpcd = 1.02,
    net_rate = 40,
    cik_turn_limit = 180,
    freelook_yaw_max = 98,
    freelook_pitch_max = 72,
    freelook_sens = 1.33,
    freelook_smooth = 60,
    freelook_return = 10,
    freelook_roll = 0.3,
    reload_head_delay = 0,
    reload_head_time = 1.32,
    reload_head_pitch = 24,
    reload_head_speed = 10.1,
    optic_virtual_eye = false,
    walk_invert = true,
    sprint_roll_invert = true,
    cam_turn_roll_invert = true,
    ads_head_roll_invert = true,
    freelook_roll_invert = true,
    lowready_safe_lowers = true,
    lowready_block = true,
}
local function DV(id, def)
    local v = SD[id]
    if v == nil then return def end
    return v
end

local cats = {}
local cur
local function Cat(name) cur = { name = name, items = {} }; cats[#cats + 1] = cur end
local function Num(id, def, min, max, dec, label, userinfo)
    def = DV(id, def)
    cv[id] = CreateClientConVar("truefp_" .. id, tostring(def), true, userinfo and true or false)
    cur.items[#cur.items + 1] = { t = "num", id = id, def = def, min = min, max = max, dec = dec, label = label }
end
local function Bool(id, def, label, userinfo)
    def = DV(id, def)
    cv[id] = CreateClientConVar("truefp_" .. id, def and "1" or "0", true, userinfo and true or false)
    cur.items[#cur.items + 1] = { t = "bool", id = id, def = def and 1 or 0, label = label }
end
local function Ext(cvar, label, t, min, max, dec)
    cur.items[#cur.items + 1] = { t = t or "bool", ext = cvar, label = label, min = min, max = max, dec = dec }
end
-- выключенная группа обнуляет свои параметры
local FGATE = {
    sway_mouse = "f_sway", tremor_amp = "f_tremor", sprint_roll = "f_sprint", sprint_roll_base = "f_sprint",
    strafe_lean = "f_lean", pivot_roll = "f_lean", accel_pitch = "f_lean", air_pitch = "f_lean", land_weapon = "f_lean",
    step_shake = "f_stepshake", cam_strafe_roll = "f_camroll", cam_turn_roll = "f_camroll", ads_head_roll = "f_camroll",
    bob_z = "f_camroll", bob_x = "f_camroll", bob_roll = "f_camroll", land_cam = "f_camroll", jump_cam = "f_camroll",
    breath_amp = "f_breath",
}
local function F(id)
    local g = FGATE[id]
    if g and cv[g] and not cv[g]:GetBool() then return 0 end
    return cv[id]:GetFloat()
end
local function B(id) return cv[id]:GetBool() end

Cat("Группы (вкл/выкл)")
Bool("f_sway", true, "Свэй от мыши")
Bool("f_tremor", true, "Тремор рук")
Bool("f_sprint", true, "Бег (roll)")
Bool("f_lean", true, "Наклон при движении")
Bool("f_stepshake", true, "Тряска камеры при шагах")
Bool("f_camroll", true, "Покачивание и крен камеры")
Bool("f_breath", true, "Дыхание")
Bool("f_cik", false, "Contact IK: отмена и пропуск руки TPIK")
Bool("move_enable", true, "Скорость, инерция и пауза прыжка", true)

Cat("Общее")
Bool("motion_enable", true, "Включить свэй и эффекты камеры")
Num("weapon_motion", 1, 0, 3, 2, "Общая сила движения оружия")
Num("camera_motion", 1, 0, 3, 2, "Общая сила эффектов камеры")

Cat("Свэй: инерция от мыши")
Num("sway_mouse", 1, 0, 4, 2, "Сила инерции")
Num("sway_mouse_pitch", 1, 0, 3, 2, "Pitch (вверх/вниз)")
Num("sway_mouse_yaw", 1, 0, 3, 2, "Yaw (влево/вправо)")
Num("sway_mouse_roll", 0.6, 0, 3, 2, "Roll от поворота")
Num("sway_speed", 9, 1, 30, 1, "Скорость возврата")
Num("sway_bounce", 0.45, 0.15, 1.5, 2, "Упругость (меньше = больше колебаний)")
Num("sway_max", 12, 2, 30, 0, "Макс. отклонение (градусы)")
Bool("sway_invert", false, "Инвертировать инерцию (pitch/yaw)")
Bool("sway_roll_invert", false, "Инвертировать roll от поворота")

Cat("Freeaim (только от бедра)")
Bool("freeaim_enable", true, "Включить freeaim")
Num("freeaim_gain", 0.6, 0, 2, 2, "Смещение оружия вслед за мышью (в сторону движения)")
Num("freeaim_yaw_limit", 9, 0, 30, 1, "Лимит по горизонтали (градусы)")
Num("freeaim_pitch_limit", 6, 0, 30, 1, "Лимит по вертикали (градусы)")
Num("freeaim_return", 0, 0, 20, 1, "Возврат к центру (0 = не возвращается)")
Num("freeaim_roll", 0.5, 0, 3, 2, "Roll от freeaim (направил влево = завал вправо)")
Num("freeaim_smooth", 22, 4, 60, 0, "Плавность freeaim")
Num("freeaim_ads_return", 8, 0, 30, 1, "Скорость сброса freeaim при прицеливании (в прицеле freeaim не работает)")
Bool("freeaim_invert", false, "Инвертировать freeaim")
Bool("freeaim_roll_invert", false, "Инвертировать roll freeaim")

Cat("Резкие повороты (оружие отстаёт)")
Bool("whip_enable", true, "Включить сильное отставание при резких поворотах")
Num("whip_threshold", 350, 100, 1500, 0, "С какой скорости поворота (град/сек) оружие начинает отставать")
Num("whip_strength", 0.85, 0, 1, 2, "Какая часть поворота теряется (1 = оружие стоит на месте)")
Num("whip_max", 110, 20, 180, 0, "Макс. отставание (градусы)")
Num("whip_return", 2.2, 0.3, 12, 1, "Скорость возврата (меньше = медленнее)")
Num("whip_roll", 0.12, 0, 0.5, 2, "Roll при отставании (градусов на градус)")
Num("whip_ads_mult", 0.35, 0, 1, 2, "Отставание в прицеле (множитель)")
Num("whip_pivot_fwd", 0, -20, 40, 0, "Ось отставания: вперёд (юниты)")
Num("whip_pivot_up", -10, -30, 20, 0, "Ось отставания: вверх (юниты)")
Bool("whip_invert", false, "Инвертировать направление отставания")

Cat("Ходьба: приклад и дуло")
Bool("walk_enable", true, "Включить качание при ходьбе")
Num("walk_pitch", 1.6, 0, 8, 2, "Pitch (градусы)")
Num("walk_yaw", 2.2, 0, 8, 2, "Yaw (градусы)")
Num("walk_roll", 2.6, 0, 10, 2, "Roll вокруг оси ствола (градусы)")
Num("walk_pos_x", 0.45, 0, 3, 2, "Смещение вбок (юниты)")
Num("walk_pos_z", 0.6, 0, 3, 2, "Смещение вверх/вниз (юниты)")
Num("walk_stock_amp", 1, 0, 3, 2, "Качание вокруг приклада (дуло гуляет)")
Num("walk_muzzle_amp", 0.7, 0, 3, 2, "Качание вокруг дула (приклад гуляет)")
Num("walk_muzzle_phase", 90, 0, 180, 0, "Сдвиг фазы дула (градусы)")
Num("stock_dist", 14, 2, 40, 0, "Точка приклада: назад от оружия (юниты)")
Num("muzzle_dist", 22, 2, 60, 0, "Точка дула: вперёд от оружия (юниты)")
Num("step_stride", 80, 40, 160, 0, "Длина шага (юниты), меньше = чаще")
Bool("walk_invert", false, "Инвертировать направление качания")
Num("tremor_amp", 0.12, 0, 1, 2, "Тремор рук: амплитуда (градусы)")
Num("tremor_speed", 1, 0.3, 3, 2, "Тремор рук: скорость")
Num("tremor_walk_mult", 2.5, 0, 6, 1, "Тремор рук: усиление при ходьбе")

Cat("Бег (как CoD4 MW 2007: только roll)")
Num("sprint_roll", 9, 0, 30, 1, "Roll при беге (градусы)")
Num("sprint_roll_base", 0, -30, 30, 1, "Постоянный наклон при беге (градусы)")
Num("sprint_walk_keep", 0.15, 0, 1, 2, "Сколько качания ходьбы остаётся при беге")
Num("sprint_blend_speed", 7, 1, 20, 1, "Скорость перехода в бег")
Bool("sprint_roll_invert", false, "Инвертировать roll бега")

Cat("Наклон оружия при движении")
Num("strafe_lean", 4, 0, 15, 1, "Завал в сторону движения (градусы)")
Num("strafe_lean_speed", 7, 1, 20, 1, "Скорость завала")
Bool("strafe_lean_invert", false, "Инвертировать завал")
Num("pivot_roll", 3, 0, 15, 1, "Pivot roll: инерция при старте/остановке (против движения)")
Num("pivot_speed", 6, 1, 20, 1, "Скорость возврата pivot roll")
Bool("pivot_invert", false, "Инвертировать pivot roll")
Num("accel_pitch", 1.2, 0, 6, 2, "Наклон при разгоне вперёд/назад")
Num("air_pitch", 3, 0, 10, 1, "Подъём/опускание в прыжке")
Num("land_weapon", 1, 0, 3, 2, "Удар оружия при приземлении")
Num("pivot_fwd", 12, 0, 40, 0, "Точка вращения: вперёд (юниты)")
Num("pivot_up", -5, -20, 20, 0, "Точка вращения: вверх (юниты)")
Num("pivot_left", 0, -20, 20, 0, "Точка вращения: влево (юниты)")

Cat("Прицеливание (ADS)")
Num("ads_sway_mult", 0.3, 0, 1, 2, "Свэй в прицеле (множитель)")
Num("ads_walk_mult", 0.55, 0, 1, 2, "Качание при ходьбе в прицеле")
Num("ads_speed_mult", 0.6, 0.1, 1.5, 2, "Скорость свэя в прицеле")
Num("ads_zoom", 1.15, 0.8, 3, 2, "Зум FOV при ADS (множитель)")
Num("ads_zoom_speed", 10, 1, 30, 1, "Скорость зума FOV")
Bool("optic_virtual_eye", true, "Оптика: картинка и сетка идут за оружием (убирает «луну» при свэе)")
Num("optic_cam_motion", 0, 0, 1, 2, "Оптика: доля движения оружия, переносимая на камеру (0 = оружие качается само)")
Num("cam_follow", 0.5, 0, 1, 2, "Оружие следует за тряской камеры (от бедра)")
Num("cam_follow_ads", 0.85, 0, 1, 2, "Оружие следует за тряской камеры (в прицеле)")

Cat("Камера: тряска от шагов")
Num("step_shake", 1, 0, 4, 2, "Сила тряски на каждый шаг")
Num("step_pitch", 0.8, 0, 3, 2, "Толчок вниз (градусы)")
Num("step_roll", 1.0, 0, 3, 2, "Наклон на шаг (градусы)")
Num("step_yaw", 0.25, 0, 2, 2, "Поворот на шаг (градусы)")
Num("step_z", 0.5, 0, 3, 2, "Проседание на шаг (юниты)")
Num("step_sprint_mult", 1.6, 0.5, 3, 2, "Множитель при беге")
Num("step_ads_mult", 0.35, 0, 1, 2, "Множитель в прицеле")
Num("step_speed", 13, 3, 40, 1, "Скорость затухания")
Num("step_bounce", 0.4, 0.15, 1.5, 2, "Упругость (меньше = дольше трясёт)")

Cat("Камера: покачивание и крен")
Num("bob_z", 0.25, 0, 2, 2, "Viewbob: вверх/вниз (юниты)")
Num("bob_x", 0.18, 0, 2, 2, "Viewbob: вбок (юниты)")
Num("bob_roll", 0.35, 0, 3, 2, "Viewbob: roll (градусы)")
Num("cam_strafe_roll", 2.6, 0, 10, 2, "Крен камеры при стрейфе: вправо = вправо (градусы)")
Bool("cam_strafe_roll_invert", false, "Инвертировать крен при стрейфе")
Num("cam_turn_roll", 0.03, 0, 0.12, 3, "Крен при повороте мышью: вправо = завал влево")
Bool("cam_turn_roll_invert", false, "Инвертировать крен при повороте")
Num("cam_roll_ads_mult", 0.6, 0, 1, 2, "Крен камеры в прицеле (множитель)")
Num("ads_head_roll", 4, 0, 15, 1, "Наклон головы в прицеле (roll, градусы)")
Bool("ads_head_roll_invert", false, "Инвертировать наклон головы в прицеле")
Num("land_cam", 1, 0, 3, 2, "Удар камеры при приземлении")
Num("jump_cam", 0.5, 0, 3, 2, "Толчок камеры при прыжке")
Num("breath_amp", 0.35, 0, 2, 2, "Дыхание: амплитуда оружия (градусы)")
Num("breath_speed", 0.9, 0.2, 3, 2, "Дыхание: скорость")

Cat("Отдача (анимированная)")
Bool("recoil_enable", true, "Включить анимированную отдачу оружия")
Num("recoil_pitch", 3.2, 0, 12, 2, "Отдача по pitch: подброс дула вверх за выстрел (градусы)")
Num("recoil_yaw", 1.8, 0, 8, 2, "Отдача по yaw: увод в сторону за выстрел (градусы)")
Num("recoil_roll", 0.6, 0, 8, 2, "Roll отдачи (градусы)")
Num("recoil_back", 0.8, 0, 6, 2, "Откат назад (юниты)")
Num("recoil_recover", 9, 2, 30, 1, "Скорость возврата оружия")
Num("recoil_bounce", 0.35, 0.15, 1.2, 2, "Упругость (меньше = сильнее гуляет после выстрела)")
Num("recoil_drift", 0.5, 0, 2, 2, "Накопление увода в одну сторону")
Num("recoil_climb", 0.35, 0, 2, 2, "Подъём дула при очереди: добавка за каждый выстрел (градусы)")
Num("recoil_climb_max", 6, 1, 20, 0, "Подъём дула: максимум накопленных выстрелов")
Num("recoil_climb_decay", 2.2, 0.3, 8, 1, "Подъём дула: скорость опускания после очереди")
Num("recoil_heat", 0.25, 0, 1, 2, "Разогрев свэя за выстрел")
Num("recoil_heat_decay", 0.6, 0.1, 3, 2, "Остывание свэя (1/сек)")
Num("recoil_sway_mult", 1.5, 0, 5, 2, "Усиление свэя от разогрева")
Num("recoil_wander", 1.0, 0, 4, 2, "Блуждание оружия от разогрева (градусы)")
Num("recoil_ads_mult", 0.6, 0, 1, 2, "Отдача в прицеле (множитель)")

Cat("Усталость рук и low ready")
Bool("fatigue_enable", true, "Усталость рук в прицеле")
Num("fatigue_time", 8, 2, 40, 1, "За сколько секунд в прицеле руки забиваются")
Num("fatigue_recover", 3, 0.5, 20, 1, "Секунд на восстановление")
Num("fatigue_tremor", 6, 0, 15, 1, "Усиление тремора при усталости")
Num("fatigue_wander", 1.4, 0, 6, 2, "Блуждание оружия при усталости (градусы)")
Num("fatigue_camera", 0.25, 0, 2, 2, "Дрожь камеры при усталости (градусы)")
Bool("lowready_enable", true, "Low ready: опускать оружие от бедра при бездействии")
Num("lowready_delay", 6, 1, 60, 1, "Через сколько секунд без действий опускать")
Num("lowready_pitch", 38, 5, 70, 0, "Угол опускания (градусы)")
Num("lowready_speed", 3.5, 1, 15, 1, "Скорость опускания и возврата")
Bool("lowready_block", true, "Первое нажатие огня только поднимает оружие (без выстрела)")
Num("lowready_block_threshold", 0.35, 0.05, 0.9, 2, "Насколько оружие должно быть опущено, чтобы блокировать выстрел")
Bool("lowready_safe_lowers", false, "Предохранитель опускает оружие (иначе восстанавливает)")

Cat("Движение игрока (серверное)")
Num("mv_walk", 0, 0, 500, 0, "Скорость ходьбы (0 = стандартная)", true)
Num("mv_run", 0, 0, 800, 0, "Скорость бега (0 = стандартная)", true)
Num("mv_inertia", 0, 0, 10, 1, "Инерция игрока (0 = выкл, больше = дольше разгон и торможение)", true)
Num("mv_jumpcd", 0, 0, 5, 2, "Пауза между прыжками после приземления (сек)", true)

Cat("Сеть, дуло и Contact IK")
Bool("net_send", true, "Показывать мои движения другим игрокам")
Bool("net_receive", true, "Показывать движения других игроков")
Num("net_rate", 20, 5, 40, 0, "Частота отправки движений (раз в секунду)")
Ext("arc9_muzzle_laser_enable", "Траектория из дула (True Aim): выстрел идёт по стволу, в прицеле и от бедра", "bool")
Ext("arc9_muzzle_laser_visible", "Показывать лазер траектории (отладка)", "bool")
Ext("arc9_bf_muzzle_netrate", "Частота отправки дула на сервер (раз в секунду)", "num", 10, 120, 0)
Num("cik_turn_limit", 100, 40, 180, 0, "Contact IK: отменять, если объект дальше этого угла от взгляда (градусы)")

Cat("Freelook (камера отдельно от оружия)")
Bool("freelook_enable", true, "Включить freelook")
Bool("freelook_toggle", false, "Режим переключения (вместо удержания)")
Num("freelook_yaw_max", 120, 20, 180, 0, "Макс. поворот по горизонтали (градусы)")
Num("freelook_pitch_max", 75, 10, 89, 0, "Макс. поворот по вертикали (градусы)")
Num("freelook_sens", 1, 0.2, 3, 2, "Чувствительность")
Num("freelook_smooth", 18, 3, 60, 0, "Плавность камеры")
Num("freelook_return", 10, 1, 40, 1, "Скорость возврата камеры")
Num("freelook_roll", 0.07, 0, 0.3, 3, "Крен при freelook (градусов на градус поворота)")
Bool("freelook_roll_invert", false, "Инвертировать крен при freelook")

Cat("Перезарядка: взгляд вниз")
Bool("reload_head_enable", true, "Опускать голову при перезарядке")
Num("reload_head_delay", 0.5, 0, 3, 2, "Через сколько секунд после начала")
Num("reload_head_time", 1, 0.2, 4, 2, "Сколько держать голову внизу (сек)")
Num("reload_head_pitch", 16, 0, 40, 0, "Наклон вниз (градусы)")
Num("reload_head_speed", 5, 1, 20, 1, "Скорость движения головы")
cv.freelook_key = CreateClientConVar("truefp_freelook_key", tostring(KEY_LALT), true, false)

-- ---------------------------------------------------------------- пружины
local function Spr() return { x = 0, v = 0 } end
local function StepSpring(s, target, speed, zeta, dt)
    local n = math.max(1, math.ceil(dt / 0.006))
    local h = dt / n
    local k, c = speed * speed, 2 * zeta * speed
    for _ = 1, n do
        s.v = s.v + (-k * (s.x - target) - c * s.v) * h
        s.x = s.x + s.v * h
    end
    return s.x
end
local function Alpha(speed, dt) return 1 - math.exp(-speed * dt) end
local function Clamp(x, a, b) return math.max(a, math.min(b, x)) end

local SPRINGS = { "sp", "sy", "sr", "wp", "wy", "wr", "wx", "wz", "wf", "sl", "pv", "ap", "air",
                  "cp", "cy", "cr", "cz", "cx", "csr", "ctr", "rh", "rp", "ry", "rr", "rb", "lr", "whip" }
local st

function M.Reset()
    st = {
        cmdAng = st and st.cmdAng or nil, accYaw = 0, accPitch = 0,
        fa = { yaw = 0, pitch = 0 }, faS = { yaw = 0, pitch = 0 },
        fl = { yaw = 0, pitch = 0 }, flA = { yaw = 0, pitch = 0 },
        flToggled = false, flKeyWas = false, flHeld = false,
        cycle = 0, lastStep = 0, walkAmp = 0, lastLat = 0, lastLon = 0,
        wasGround = true, lastVz = 0, zoomSa = 0, fired = false, sprintB = 0, relOn = false, relT0 = 0,
        yawVelS = 0, climb = 0, fatigue = 0, heat = 0, shake = 0, drift = 0, lrIdle = 0, lastSafe = false, attackHeld = false, lrBlock = false, lrWpn = nil,
        out = {
            cam = { pos = Vector(0, 0, 0), ang = Angle(0, 0, 0) },
            wpn = { pos = Vector(0, 0, 0), ang = Angle(0, 0, 0), pivot = Vector(12, 0, -5),
                    whip = 0, whipPivot = Vector(0, 0, -10),
                    stock = Angle(0, 0, 0), muz = Angle(0, 0, 0), axisRoll = 0, stockDist = 14, muzDist = 22 },
            freelook = { pitch = 0, yaw = 0, roll = 0 },
            follow = 0.5, zoom = 1, headRoll = 0,
        },
    }
    for _, n in ipairs(SPRINGS) do st[n] = Spr() end
end
M.Reset()

-- ---------------------------------------------------------------- ввод (CreateMove)
local function FreelookHeld()
    if not B("freelook_enable") then return false end
    local ply = LocalPlayer()
    if gui.IsGameUIVisible() or vgui.CursorVisible() or ply:IsTyping() then return false end
    local key = cv.freelook_key:GetInt()
    local down = key > 0 and input.IsKeyDown(key)
    if B("freelook_toggle") then
        if down and not st.flKeyWas then st.flToggled = not st.flToggled end
        st.flKeyWas = down
        return st.flToggled
    end
    st.flKeyWas = down
    st.flToggled = false
    return down
end

hook.Add("CreateMove", "TFPBC_Motion_Input", function(cmd)
    local va = cmd:GetViewAngles()
    if not TFPBC.IsActive() then
        st.cmdAng = Angle(va.p, va.y, va.r)
        st.flHeld = false
        st.attackHeld = false
        return
    end

    -- low ready: пока оружие опущено, первое нажатие огня его только поднимает (выстрела нет)
    st.attackHeld = cmd:KeyDown(IN_ATTACK)
    if st.lrBlock and not st.attackHeld then st.lrBlock = false end
    if st.attackHeld and B("lowready_enable") and B("lowready_block") then
        local w = LocalPlayer():GetActiveWeapon()
        if IsValid(w) and w.ARC9 and not (w.GetSafe and w:GetSafe()) then
            if st.lr.x > F("lowready_block_threshold") then st.lrBlock = true end
            if st.lrBlock then cmd:RemoveKey(IN_ATTACK) end
        end
    end
    if not st.cmdAng then st.cmdAng = Angle(va.p, va.y, va.r) end

    st.flHeld = FreelookHeld()
    if st.flHeld then
        -- мышь крутит только камеру; направление оружия и стрельбы не меняется
        local sens = F("freelook_sens")
        local dy = math.AngleDifference(va.y, st.cmdAng.y) * sens
        local dp = (va.p - st.cmdAng.p) * sens
        st.fl.yaw = Clamp(st.fl.yaw + dy, -F("freelook_yaw_max"), F("freelook_yaw_max"))
        st.fl.pitch = Clamp(st.fl.pitch + dp, -F("freelook_pitch_max"), F("freelook_pitch_max"))
        cmd:SetViewAngles(st.cmdAng)
    else
        local dy = math.AngleDifference(va.y, st.cmdAng.y)
        local dp = va.p - st.cmdAng.p
        st.accYaw = st.accYaw + dy
        st.accPitch = st.accPitch + dp
        st.cmdAng = Angle(va.p, va.y, va.r)
    end
end)

hook.Add("EntityFireBullets", "TFPBC_Motion_Fire", function(ent)
    if ent == LocalPlayer() then st.fired = true end
end)

-- ---------------------------------------------------------------- основной расчёт
-- sa: 0 = от бедра, 1 = прицеливание
local function Noise(t, s)
    return (math.sin(t * 7.3 + s) + 0.6 * math.sin(t * 11.7 + s * 1.7) + 0.35 * math.sin(t * 17.9 + s * 2.3)) / 1.95
end

-- активный прицел - оптика с увеличением (а не механика и не коллиматор)?
local function IsOpticScope(wpn)
    if not IsValid(wpn) or not wpn.ARC9 or not wpn.GetSight then return false end
    local ok, at = pcall(wpn.IsScoping, wpn)
    if ok and at and not at.RTCollimator and not at.HoloSight then return true end
    local sight = wpn:GetSight()
    local slot = sight and sight.slottbl
    local att = slot and wpn.GetFinalAttTable and wpn:GetFinalAttTable(slot)
    if att and att.HoloSight then return false end
    local okz, z = pcall(wpn.GetRealZoom, wpn, sight)
    return (okz and z and z > 1.25) and true or false
end

M.IsOpticScope = IsOpticScope

local function IsReloading(wpn)
    if not IsValid(wpn) then return false end
    if wpn.GetReloading then
        local ok, r = pcall(wpn.GetReloading, wpn)
        if ok then return r and true or false end
    end
    return wpn:GetActivity() == ACT_VM_RELOAD
end

function M.Update(ply, dt, aimAng, sa, wpn)
    dt = Clamp(dt, 0.0005, 0.05)
    local o = st.out
    st.t = (st.t or 0) + dt

    -- ---- freelook (работает независимо от свэя)
    if st.flHeld then
        -- накапливается в CreateMove
    else
        local d = math.exp(-F("freelook_return") * dt)
        st.fl.yaw, st.fl.pitch = st.fl.yaw * d, st.fl.pitch * d
        if math.abs(st.fl.yaw) < 0.02 then st.fl.yaw = 0 end
        if math.abs(st.fl.pitch) < 0.02 then st.fl.pitch = 0 end
    end
    local fa_ = Alpha(F("freelook_smooth"), dt)
    st.flA.yaw = Lerp(fa_, st.flA.yaw, st.fl.yaw)
    st.flA.pitch = Lerp(fa_, st.flA.pitch, st.fl.pitch)
    -- перезарядка: через delay секунд голова опускается, через time секунд поднимается
    local reloading = B("reload_head_enable") and IsReloading(wpn)
    if reloading and not st.relOn then st.relOn, st.relT0 = true, CurTime() end
    if not reloading then st.relOn = false end
    local relTarget = 0
    if st.relOn then
        local t = CurTime() - st.relT0
        if t >= F("reload_head_delay") and t < F("reload_head_delay") + F("reload_head_time") then
            relTarget = F("reload_head_pitch")
        end
    end
    StepSpring(st.rh, relTarget, F("reload_head_speed"), 0.95, dt)

    o.freelook.yaw = st.flA.yaw
    o.freelook.pitch = st.flA.pitch + st.rh.x
    -- крен головы при freelook: пропорционален повороту и уходит вместе с ним
    o.freelook.roll = -st.flA.yaw * F("freelook_roll") * (B("freelook_roll_invert") and -1 or 1)

    -- ---- зум FOV в ADS (плавно, независимо)
    st.zoomSa = Lerp(Alpha(F("ads_zoom_speed"), dt), st.zoomSa, sa)
    o.zoom = Lerp(st.zoomSa, 1, F("ads_zoom"))
    -- наклон головы к прицелу
    o.headRoll = st.zoomSa * F("ads_head_roll") * (B("ads_head_roll_invert") and -1 or 1)

    local dY, dP = Clamp(st.accYaw, -40, 40), Clamp(st.accPitch, -40, 40)
    st.accYaw, st.accPitch = 0, 0

    if not B("motion_enable") then
        o.cam.pos:Zero(); o.cam.ang:Zero(); o.wpn.pos:Zero(); o.wpn.ang:Zero()
        o.wpn.stock:Zero(); o.wpn.muz:Zero(); o.wpn.axisRoll = 0; o.wpn.whip = 0
        o.follow = 1
        st.fired = false
        st.lr.x, st.lr.v, st.lrBlock = 0, 0, false
        return o
    end

    -- ---- входные величины
    local vel = ply:GetVelocity()
    local onGround = ply:OnGround()
    local speed = math.sqrt(vel.x * vel.x + vel.y * vel.y)
    local yawAng = Angle(0, aimAng.y, 0)
    local cfgWalk = cv.mv_walk and cv.mv_walk:GetFloat() or 0
    local ws = math.max(cfgWalk > 0 and cfgWalk or ply:GetWalkSpeed(), 100)
    local lat = Clamp(vel:Dot(yawAng:Right()) / ws, -1.5, 1.5)
    local lon = Clamp(vel:Dot(yawAng:Forward()) / ws, -1.5, 1.5)
    local sprint = ply:KeyDown(IN_SPEED) and speed > ws * 1.1
    local yawVel = dY / dt

    -- множители прицеливания: полегче и помедленнее
    local kA = Lerp(sa, 1, F("ads_sway_mult"))
    local kW = Lerp(sa, 1, F("ads_walk_mult"))
    local kS = Lerp(sa, 1, F("ads_speed_mult"))
    local kC = Lerp(sa, 1, F("step_ads_mult"))
    local kR = Lerp(sa, 1, F("cam_roll_ads_mult"))

    -- ---- свэй от мыши (пружины)
    local sgn = B("sway_invert") and -1 or 1
    local g = F("sway_mouse") * kA * (1 + Clamp(st.heat, 0, 2) * F("recoil_sway_mult"))
    local smax = F("sway_max")
    st.sy.x = Clamp(st.sy.x - dY * g * F("sway_mouse_yaw") * sgn, -smax, smax)
    st.sp.x = Clamp(st.sp.x - dP * g * F("sway_mouse_pitch") * sgn, -smax, smax)
    local rsgn = B("sway_roll_invert") and -1 or 1
    st.sr.x = Clamp(st.sr.x + dY * 0.5 * g * F("sway_mouse_roll") * rsgn, -smax, smax)
    local sspeed, sz = F("sway_speed") * kS, F("sway_bounce")
    StepSpring(st.sy, 0, sspeed, sz, dt)
    StepSpring(st.sp, 0, sspeed, sz, dt)
    StepSpring(st.sr, 0, sspeed, sz, dt)

    -- ---- freeaim: смещение копится, назад не возвращается (если return = 0)
    local faYaw, faPitch, faRoll = 0, 0, 0
    if B("freeaim_enable") then
        local fg = F("freeaim_gain") * (B("freeaim_invert") and -1 or 1)
        -- freeaim только от бедра: в прицеле его нет
        local ylim, plim = F("freeaim_yaw_limit"), F("freeaim_pitch_limit")
        local fa = st.fa
        if sa < 0.05 then
            -- оружие смещается в сторону движения мыши (как в deadzone freeaim)
            fa.yaw = Clamp(fa.yaw + dY * fg, -ylim, ylim)
            fa.pitch = Clamp(fa.pitch + dP * fg, -plim, plim)
        end
        local ret = F("freeaim_return")
        if ret > 0 then
            local d = math.exp(-ret * dt)
            fa.yaw, fa.pitch = fa.yaw * d, fa.pitch * d
        end
        if sa > 0.05 then
            local d = math.exp(-F("freeaim_ads_return") * dt)
            fa.yaw, fa.pitch = fa.yaw * d, fa.pitch * d
        end
        local ks = Alpha(F("freeaim_smooth"), dt)
        st.faS.yaw = Lerp(ks, st.faS.yaw, fa.yaw)
        st.faS.pitch = Lerp(ks, st.faS.pitch, fa.pitch)
        local hip = 1 - Clamp(sa * 1.5, 0, 1)
        faYaw, faPitch = st.faS.yaw * hip, st.faS.pitch * hip
        -- направил влево (yaw > 0) -> завал на правый бок (roll > 0); вправо -> на левый
        faRoll = faYaw * F("freeaim_roll") * (B("freeaim_roll_invert") and -1 or 1)
    else
        st.fa.yaw, st.fa.pitch, st.faS.yaw, st.faS.pitch = 0, 0, 0, 0
    end

    -- ---- резкие повороты: оружие дико отстаёт и медленно возвращается к позиции freeaim
    local whipRoll = 0
    if B("whip_enable") then
        st.yawVelS = Lerp(Alpha(25, dt), st.yawVelS, yawVel)
        local thr = F("whip_threshold")
        local f = Clamp((math.abs(st.yawVelS) - thr) / math.max(thr * 0.6, 1), 0, 1)
        f = f * f * (3 - 2 * f)
        local wk = f * F("whip_strength") * Lerp(sa, 1, F("whip_ads_mult")) * (B("whip_invert") and -1 or 1)
        local wmax = F("whip_max")
        -- камера повернулась на dY, оружие остаётся у старого направления (смещение копится)
        st.whip.x = Clamp(st.whip.x - dY * wk, -wmax, wmax)
        StepSpring(st.whip, 0, F("whip_return"), 1.0, dt)
        whipRoll = st.whip.x * F("whip_roll") * (B("freeaim_roll_invert") and -1 or 1)
    else
        st.whip.x, st.whip.v = 0, 0
    end

    -- ---- шаги и цикл ходьбы
    local moving = onGround and speed > 15
    st.walkAmp = Lerp(Alpha(moving and 7 or 5, dt), st.walkAmp, moving and math.min(speed / ws, 1.8) or 0)
    if moving then st.cycle = st.cycle + math.pi * speed * dt / math.max(F("step_stride"), 10) end
    local c = st.cycle

    -- переход в бег: ходьба затухает, остаётся roll вокруг оси ствола
    st.sprintB = Lerp(Alpha(F("sprint_blend_speed"), dt), st.sprintB, (sprint and moving) and 1 or 0)
    local sb = st.sprintB
    local A = st.walkAmp * kW * Lerp(sb, 1, F("sprint_walk_keep"))
    if not B("walk_enable") then A = 0 end
    local wsg = B("walk_invert") and -1 or 1
    local stepWave = -math.cos(2 * c) * 0.5 + 0.5
    -- слой 1: вращение вокруг приклада (дуло гуляет)
    local stockAmp = F("walk_stock_amp")
    local stockYaw = math.sin(c) * F("walk_yaw") * A * wsg * stockAmp
    local stockPitch = stepWave * F("walk_pitch") * A * stockAmp
    -- слой 2: вращение вокруг дула (приклад гуляет), со сдвигом фазы
    local ph = math.rad(F("walk_muzzle_phase"))
    local muzAmp = F("walk_muzzle_amp")
    local muzYaw = math.sin(c + ph) * F("walk_yaw") * A * wsg * muzAmp
    local muzPitch = (-math.cos(2 * c + ph) * 0.5 + 0.5) * F("walk_pitch") * A * muzAmp
    -- roll вокруг оси приклад-дуло: ходьба + бег
    local srg = B("sprint_roll_invert") and -1 or 1
    local axisRoll = math.sin(c) * F("walk_roll") * A * wsg
        + (math.sin(c) * F("sprint_roll") + F("sprint_roll_base")) * sb * srg
    local walkPosX = math.sin(c) * F("walk_pos_x") * A * wsg
    local walkPosZ = (-math.cos(2 * c) * 0.5) * F("walk_pos_z") * A

    -- тремор рук: растёт при ходьбе, в прицеле слабее
    local ta = F("tremor_amp") * (1 + st.walkAmp * F("tremor_walk_mult") + st.fatigue * F("fatigue_tremor") + Clamp(st.heat, 0, 2) * 0.5) * Lerp(sa, 1, 0.6)
    local tt = st.t * F("tremor_speed")
    local trP, trY, trR = Noise(tt, 0) * ta, Noise(tt, 2.1) * ta, Noise(tt, 4.2) * ta * 0.6

    -- ---- усталость рук: в прицеле нарастает тремор и блуждание, вне прицела проходит
    if B("fatigue_enable") and sa > 0.5 then
        st.fatigue = Clamp(st.fatigue + dt / math.max(F("fatigue_time"), 0.5), 0, 1)
    else
        st.fatigue = Clamp(st.fatigue - dt / math.max(F("fatigue_recover"), 0.2), 0, 1)
    end
    st.heat = math.max(0, st.heat - F("recoil_heat_decay") * dt)
    st.drift = st.drift * math.exp(-0.8 * dt)
    local heatN = Clamp(st.heat, 0, 2)
    local wa = F("fatigue_wander") * st.fatigue + F("recoil_wander") * heatN
    local wt = st.t * 0.8
    local wanP, wanY, wanR = Noise(wt, 7.7) * wa, Noise(wt * 0.8, 9.1) * wa * 1.2, Noise(wt * 0.6, 1.3) * wa * 0.5

    -- ---- low ready (от бедра): после паузы оружие опускается; возврат - прицел, огонь, предохранитель
    local arc = IsValid(wpn) and wpn.ARC9
    if st.lrWpn ~= wpn then
        st.lrWpn, st.lrIdle = wpn, 0
        st.lr.x, st.lr.v = 0, 0
    end
    local safe = (arc and wpn.GetSafe and wpn:GetSafe()) and true or false
    if safe ~= st.lastSafe then st.lastSafe, st.lrIdle = safe, 0 end
    local action = sa > 0.1 or sprint or st.attackHeld or IsReloading(wpn)
    if action then st.lrIdle = 0 else st.lrIdle = st.lrIdle + dt end
    local lrTarget = 0
    if B("lowready_enable") and arc then
        if safe then
            lrTarget = B("lowready_safe_lowers") and 1 or 0
            if lrTarget == 0 then st.lrIdle = 0 end
        elseif st.lrIdle >= F("lowready_delay") then
            lrTarget = 1
        end
    end
    StepSpring(st.lr, lrTarget, F("lowready_speed"), 0.9, dt)
    local lr = Clamp(st.lr.x, 0, 1.1)

    -- ---- событие шага: толчок камеры (встряхивает)
    local stepIdx = math.floor(c / math.pi)
    if moving and stepIdx ~= st.lastStep then
        st.lastStep = stepIdx
        local foot = (stepIdx % 2 == 0) and 1 or -1
        local sm = F("step_shake") * (sprint and F("step_sprint_mult") or 1) * kC
        st.cp.x = st.cp.x + F("step_pitch") * sm
        st.cr.x = st.cr.x + foot * F("step_roll") * sm
        st.cy.x = st.cy.x + foot * F("step_yaw") * sm
        st.cz.x = st.cz.x - F("step_z") * sm
        st.wz.x = st.wz.x - 0.12 * sm
        st.wp.x = st.wp.x + 0.35 * sm
    end

    -- ---- наклон оружия при движении
    local lsg = B("strafe_lean_invert") and -1 or 1
    StepSpring(st.sl, lat * F("strafe_lean") * lsg * kA, F("strafe_lean_speed") * kS, 0.7, dt)
    local dLat = Clamp(lat - st.lastLat, -0.3, 0.3)
    local dLon = Clamp(lon - st.lastLon, -0.3, 0.3)
    st.lastLat, st.lastLon = lat, lon
    local psg = B("pivot_invert") and -1 or 1
    -- вправо стартуем -> оружие заваливается на левый бок и возвращается
    st.pv.x = st.pv.x - dLat * F("pivot_roll") * psg * kA
    StepSpring(st.pv, 0, F("pivot_speed") * kS, 0.5, dt)
    st.ap.x = st.ap.x - dLon * F("accel_pitch") * kA
    StepSpring(st.ap, 0, 7 * kS, 0.5, dt)

    -- ---- прыжок / приземление
    local airTarget = 0
    if not onGround then
        airTarget = Clamp(vel.z / 300, -1, 1) * F("air_pitch") * kA
        st.lastVz = vel.z
        if st.wasGround then
            st.cp.x = st.cp.x - F("jump_cam") * 1.2
        end
    elseif not st.wasGround then
        local impact = Clamp(-st.lastVz / 600, 0, 1.6)
        st.wz.x = st.wz.x - impact * F("land_weapon") * 1.2 * kA
        st.wp.x = st.wp.x + impact * F("land_weapon") * 3 * kA
        st.cp.x = st.cp.x + impact * F("land_cam") * 2.2
        st.cz.x = st.cz.x - impact * F("land_cam") * 1.8
    end
    st.wasGround = onGround
    StepSpring(st.air, airTarget, 8 * kS, 0.6, dt)

    -- детект выстрела по расходу патронов: EntityFireBullets не срабатывает при физических пулях ARC9
    if IsValid(wpn) and wpn.Clip1 then
        local clip = wpn:Clip1()
        if st.lastClipWpn == wpn and st.lastClip and clip >= 0 and clip < st.lastClip
            and st.lastClip - clip <= 3 and not IsReloading(wpn) then
            st.fired = true
        end
        st.lastClip, st.lastClipWpn = clip, wpn
    else
        st.lastClip, st.lastClipWpn = nil, nil
    end

    -- ---- выстрел: анимированная отдача (руки уводят оружие), разогрев свэя, тряска камеры
    if st.fired then
        st.fired = false
        local ka = Lerp(sa, 1, F("recoil_ads_mult"))
        local rs = (math.random() < 0.5) and -1 or 1
        if B("recoil_enable") then
            st.drift = Clamp(st.drift + (math.random() * 2 - 1) * 0.5 * F("recoil_drift"), -1.5, 1.5)
            st.rp.x = st.rp.x - F("recoil_pitch") * (0.8 + math.random() * 0.4) * ka
            st.ry.x = st.ry.x + ((math.random() * 2 - 1) + st.drift) * F("recoil_yaw") * ka
            st.rr.x = st.rr.x + (math.random() * 2 - 1) * F("recoil_roll") * ka
            st.rb.x = st.rb.x + F("recoil_back") * ka
            st.heat = Clamp(st.heat + F("recoil_heat"), 0, 2)
        end
        st.climb = Clamp(st.climb + 1, 0, F("recoil_climb_max"))
    end
    st.climb = st.climb * math.exp(-F("recoil_climb_decay") * dt)
    -- накопленный подъём дула (pitch) и увод (yaw) при очереди
    local climbK = Lerp(sa, 1, F("recoil_ads_mult")) * st.climb * F("recoil_climb") * (B("recoil_enable") and 1 or 0)
    local climbP = -climbK
    local climbY = st.drift * climbK * 0.6
    local rsp, rbn = F("recoil_recover") * kS, F("recoil_bounce")
    StepSpring(st.rp, 0, rsp, rbn, dt)
    StepSpring(st.ry, 0, rsp, rbn, dt)
    StepSpring(st.rr, 0, rsp, rbn, dt)
    StepSpring(st.rb, 0, rsp * 1.2, 0.55, dt)

    -- ---- дыхание
    local breath = F("breath_amp") * (1 - Clamp(st.walkAmp, 0, 1)) * Lerp(sa, 1, 0.5)
    local bp = math.sin(st.t * F("breath_speed") * 2 * math.pi) * breath
    local by = math.sin(st.t * F("breath_speed") * 1.3 * math.pi + 1.2) * breath * 0.6

    -- ---- пружины оружия (удары)
    StepSpring(st.wp, 0, 12 * kS, 0.45, dt)
    StepSpring(st.wy, 0, 12 * kS, 0.45, dt)
    StepSpring(st.wr, 0, 12 * kS, 0.45, dt)
    StepSpring(st.wx, 0, 12 * kS, 0.5, dt)
    StepSpring(st.wz, 0, 12 * kS, 0.45, dt)
    StepSpring(st.wf, 0, 14 * kS, 0.5, dt)

    -- ---- камера: пружины
    local cs, cz = F("step_speed") * kS, F("step_bounce")
    StepSpring(st.cp, 0, cs, cz, dt)
    StepSpring(st.cy, 0, cs, cz, dt)
    StepSpring(st.cr, 0, cs, cz, dt)
    StepSpring(st.cz, 0, cs, cz, dt)
    StepSpring(st.cx, 0, cs, cz, dt)
    local csg = B("cam_strafe_roll_invert") and -1 or 1
    StepSpring(st.csr, lat * F("cam_strafe_roll") * csg * kR, 7, 0.8, dt)
    local tsg = B("cam_turn_roll_invert") and -1 or 1
    StepSpring(st.ctr, Clamp(yawVel * F("cam_turn_roll") * tsg, -8, 8) * kR, 9, 0.8, dt)

    local bobA = st.walkAmp * kC
    local bobZ = math.sin(2 * c) * F("bob_z") * bobA
    local bobX = math.sin(c) * F("bob_x") * bobA
    local bobR = math.sin(c) * F("bob_roll") * bobA

    -- ---- итог: камера (view space: x вперёд, y влево, z вверх)
    local cm = F("camera_motion")
    o.cam.pos.x, o.cam.pos.y, o.cam.pos.z = 0, -(st.cx.x + bobX) * cm, (st.cz.x + bobZ) * cm
    local fc = st.fatigue * F("fatigue_camera")
    local ftt = st.t * 1.3
    o.cam.ang.p = (st.cp.x + Noise(ftt, 11) * fc) * cm
    o.cam.ang.y = (st.cy.x + Noise(ftt, 13) * fc * 0.8) * cm
    o.cam.ang.r = (st.cr.x + st.csr.x + st.ctr.x + bobR + Noise(ftt, 17) * fc * 0.5) * cm

    -- ---- итог: оружие
    local wm = F("weapon_motion")
    o.wpn.ang.p = (st.sp.x + faPitch + st.ap.x + st.air.x + st.wp.x + bp + trP + wanP) * wm
    o.wpn.ang.y = (st.sy.x + faYaw + st.wy.x + by + trY + wanY) * wm
    o.wpn.ang.r = (st.sr.x + faRoll + st.sl.x + st.pv.x + st.wr.x + trR + wanR) * wm
    -- отдача и low ready вращают оружие вокруг приклада (плечо), руки следуют за ним
    o.wpn.stock.p = (stockPitch + st.rp.x + climbP + lr * F("lowready_pitch")) * wm
    o.wpn.stock.y = (stockYaw + st.ry.x + climbY) * wm
    o.wpn.muz.p, o.wpn.muz.y = muzPitch * wm, muzYaw * wm
    o.wpn.axisRoll = (axisRoll + st.rr.x + whipRoll) * wm
    o.wpn.whip = st.whip.x
    o.wpn.whipPivot.x, o.wpn.whipPivot.y, o.wpn.whipPivot.z = F("whip_pivot_fwd"), 0, F("whip_pivot_up")
    o.wpn.stockDist, o.wpn.muzDist = F("stock_dist"), F("muzzle_dist")
    o.wpn.pos.x = -(st.wf.x + st.rb.x + lr * 1.0) * wm
    o.wpn.pos.y = -(walkPosX + st.wx.x) * wm
    o.wpn.pos.z = (walkPosZ + st.wz.x - lr * 2.5) * wm
    o.wpn.pivot.x, o.wpn.pivot.y, o.wpn.pivot.z = F("pivot_fwd"), F("pivot_left"), F("pivot_up")
    o.follow = Lerp(sa, F("cam_follow"), F("cam_follow_ads"))
    return o
end

-- применить движение к позе оружия в view space (lp, la): вращение вокруг точки pivot
function M.ApplyWeapon(lp, la, w, k)
    k = k or 1
    local wang, wstock, wmuz, wroll, wwhip, wpos = w.ang, w.stock, w.muz, w.axisRoll, w.whip, w.pos
    if k ~= 1 then
        wang = Angle(wang.p * k, wang.y * k, wang.r * k)
        wstock = Angle(wstock.p * k, wstock.y * k, 0)
        wmuz = Angle(wmuz.p * k, wmuz.y * k, 0)
        wroll, wwhip, wpos = wroll * k, wwhip * k, wpos * k
    end
    local m = Matrix()
    m:SetTranslation(lp)
    m:SetAngles(la)
    -- общее смещение: вращение вокруг точки pivot
    local r = Matrix()
    r:Translate(w.pivot)
    r:Rotate(wang)
    r:Translate(-w.pivot)
    m = r * m
    -- ходьба, слой 1: вокруг приклада (точка позади оружия вдоль ствола)
    local ps = m:GetTranslation() - m:GetAngles():Forward() * w.stockDist
    r = Matrix()
    r:Translate(ps)
    r:Rotate(wstock)
    r:Translate(-ps)
    m = r * m
    -- ходьба, слой 2: вокруг дула
    local pm = m:GetTranslation() + m:GetAngles():Forward() * w.muzDist
    r = Matrix()
    r:Translate(pm)
    r:Rotate(wmuz)
    r:Translate(-pm)
    m = r * m
    -- roll вокруг оси приклад-дуло (локальная ось X оружия)
    local rm = Matrix()
    rm:Rotate(Angle(0, 0, wroll))
    m = m * rm
    -- резкий поворот: всё оружие обходит вокруг оси тела (yaw > 0 = влево)
    if wwhip ~= 0 then
        r = Matrix()
        r:Translate(w.whipPivot)
        r:Rotate(Angle(0, wwhip, 0))
        r:Translate(-w.whipPivot)
        m = r * m
    end
    return m:GetTranslation() + wpos, m:GetAngles()
end

-- ---------------------------------------------------------------- сеть: экспорт/импорт
-- 12 чисел (градусы / юниты): ang p,y,r | stock p,y | muz p,y | axisRoll | pos x,y,z | whip
function M.ExportWeapon(w)
    return {
        w.ang.p, w.ang.y, w.ang.r, w.stock.p, w.stock.y, w.muz.p, w.muz.y,
        w.axisRoll, w.pos.x, w.pos.y, w.pos.z, w.whip,
    }
end

function M.NewRemoteState()
    return { cur = { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 }, target = { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 },
        on = false, t = 0, frame = -1,
        w = { pos = Vector(0, 0, 0), ang = Angle(0, 0, 0), pivot = Vector(12, 0, -5), whipPivot = Vector(0, 0, -10),
              stock = Angle(0, 0, 0), muz = Angle(0, 0, 0), axisRoll = 0, whip = 0, stockDist = 14, muzDist = 22 } }
end

function M.UpdateRemote(R, dt)
    if R.frame == FrameNumber() then return R.w end
    R.frame = FrameNumber()
    local a = Alpha(18, dt)
    for i = 1, 12 do R.cur[i] = Lerp(a, R.cur[i], R.target[i]) end
    local c, w = R.cur, R.w
    w.ang.p, w.ang.y, w.ang.r = c[1], c[2], c[3]
    w.stock.p, w.stock.y = c[4], c[5]
    w.muz.p, w.muz.y = c[6], c[7]
    w.axisRoll = c[8]
    w.pos.x, w.pos.y, w.pos.z = c[9], c[10], c[11]
    w.whip = c[12]
    w.pivot.x, w.pivot.y, w.pivot.z = F("pivot_fwd"), F("pivot_left"), F("pivot_up")
    w.stockDist, w.muzDist = F("stock_dist"), F("muzzle_dist")
    return w
end

-- ---------------------------------------------------------------- сброс к базовым значениям
function M.ResetDefaults()
    for _, c in ipairs(cats) do
        for _, it in ipairs(c.items) do
            if it.id then RunConsoleCommand("truefp_" .. it.id, tostring(it.def)) end
        end
    end
    for name, def in pairs(TFPBC.CoreDefaults or {}) do
        RunConsoleCommand("truefp_" .. name, tostring(def))
    end
    RunConsoleCommand("truefp_freelook_key", tostring(KEY_LALT))
    M.Reset()
end

concommand.Add("truefp_motion_reset", function()
    M.ResetDefaults()
    print("[TrueFP] настройки сброшены к базовым")
end)

-- миграция: у всех пользователей базовые значения одинаковы
if cv.cfgver:GetInt() < 3 then
    timer.Simple(0, function()
        M.ResetDefaults()
        RunConsoleCommand("truefp_cfgver", "3")
    end)
end
