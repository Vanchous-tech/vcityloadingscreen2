-- ============================================================================
-- TrueFP Bodycam: поддержка ARC9
--  1) worldmodel в позе viewmodel относительно камеры
--  2) RT-оптика / коллиматоры на worldmodel
--  3) смещение рук (WM) по XYZ + сброс к базовым значениям в ADS
--  4) отдельное смещение по Z при беге (wm_run_z)
-- ============================================================================
local TFPBC = TFPBC
local cv = TFPBC.CV
local v0 = Vector(0, 0, 0)

local function ARC9Weapon()
    local ply = LocalPlayer()
    if not IsValid(ply) or not ply:Alive() then return end
    local wpn = ply:GetActiveWeapon()
    if not IsValid(wpn) or not wpn.ARC9 then return end
    return ply, wpn
end

-- ============================================================ расчёт смещений рук
-- sightAmount: 0 = hip, 1 = ADS
-- wm_x/y/z плавно сбрасываются к 0 в ADS
-- wm_run_z добавляется только когда игрок бежит (IN_SPEED)
local function CalcHandOffset(ply, basePos, baseAng, sightAmount)
    -- плавный сброс к базовым значениям в ADS (множитель от 1 до 0)
    local hipFactor = 1 - sightAmount

    local wx = cv.wm_x:GetFloat() * hipFactor
    local wy = cv.wm_y:GetFloat() * hipFactor
    local wz = cv.wm_z:GetFloat() * hipFactor

    -- бег: добавляем wm_run_z по Z (только если не в ADS)
    local running = ply:KeyDown(IN_SPEED) and ply:GetVelocity():LengthSqr() > 100
    if running and hipFactor > 0 then
        wz = wz + cv.wm_run_z:GetFloat() * hipFactor
    end

    local pos = basePos + baseAng:Forward() * wy
                        + baseAng:Right()   * wx
                        + baseAng:Up()      * wz

    return pos, baseAng
end

-- ============================================================ 1. поза оружия
local function PatchWeapon(wpn)
    if wpn.TFP_Patched then return end
    wpn.TFP_Patched = true
    local orig = wpn.GetAttachmentPos

    -- пока ARC9 рендерит картинку прицела, worldmodel своего оружия (мушка, детали прицела) в кадр не попадает
    for _, fname in ipairs({ "DrawCustomModel", "DrawTranslucentPass" }) do
        local f = wpn[fname]
        if f then
            wpn[fname] = function(self, wm, ...)
                if wm and ARC9 and ARC9.OverDraw and self:GetOwner() == LocalPlayer() and TFPBC.IsActive() then return end
                return f(self, wm, ...)
            end
        end
    end

    wpn.GetAttachmentPos = function(self, slottbl, wm, idle, nomodeloffset, custompos, customang, dupli)
        if wm and not custompos and not idle and slottbl and slottbl.WMBase then
            local owner = self:GetOwner()
            if owner == LocalPlayer() then
                if self.TFP_VMPos and TFPBC.IsActive() then
                    local pos = self.TFP_VMPos
                    local ang = self.TFP_VMAng
                    local sight = math.Clamp(self:GetSightAmount() or 0, 0, 1)
                    if IsValid(owner) then
                        pos = CalcHandOffset(owner, pos, ang, sight)
                    end
                    return pos, ang, v0
                elseif TFPBC.LocalThirdPose and TFPBC.MotionAllowed() then
                    -- смотрим на себя со стороны (камера, зеркало): штатная поза + свои движения
                    local p, a, x = orig(self, slottbl, wm, idle, nomodeloffset, custompos, customang, dupli)
                    local np, na = TFPBC.LocalThirdPose(owner, p, a)
                    if np then return np, na, x end
                    return p, a, x
                end
            elseif IsValid(owner) and TFPBC.RemoteWeaponPose then
                -- чужой игрок: штатная поза в руке + его движения (свэй, отдача, low ready), присланные по сети
                local p, a, x = orig(self, slottbl, wm, idle, nomodeloffset, custompos, customang, dupli)
                local np, na = TFPBC.RemoteWeaponPose(owner, p, a)
                if np then return np, na, x end
                return p, a, x
            end
        end
        return orig(self, slottbl, wm, idle, nomodeloffset, custompos, customang, dupli)
    end
end
TFPBC.PatchWeapon = PatchWeapon

function TFPBC.OnWeaponFrame(wpn, pos, ang, fov, fx)
    PatchWeapon(wpn)

    if cv.nobob:GetBool() then
        if wpn.TFP_OrigNoBob == nil then wpn.TFP_OrigNoBob = wpn.NoViewBob or false end
        wpn.NoViewBob = true
    elseif wpn.TFP_OrigNoBob ~= nil then
        wpn.NoViewBob = wpn.TFP_OrigNoBob
        wpn.TFP_OrigNoBob = nil
    end

    if wpn.MirrorVMWM and wpn.GetViewModelPosition then
        local ok, vp, va = pcall(wpn.GetViewModelPosition, wpn, Vector(pos), Angle(ang.p, ang.y, ang.r))
        if ok and vp and va then
            local spread = cv.weapon_spread:GetFloat()
            local sight = math.Clamp(wpn:GetSightAmount() or 0, 0, 1)
            if spread ~= 1 then
                local k = Lerp(sight, spread, 1)
                local lp, la = WorldToLocal(vp, va, pos, ang)
                lp.y = lp.y * k
                lp.z = lp.z * k
                vp, va = LocalToWorld(lp, la, pos, ang)
            end
            local nomP, nomA = vp, va
            -- свэй, freeaim, шаги, отдача: смещение оружия вокруг точки вращения
            if fx and fx.wpn and TFPBC.Motion then
                local lp, la = WorldToLocal(vp, va, pos, ang)
                lp, la = TFPBC.Motion.ApplyWeapon(lp, la, fx.wpn, fx.wk)
                vp, va = LocalToWorld(lp, la, pos, ang)
            end
            wpn.TFP_VMPos, wpn.TFP_VMAng = vp, va
            -- «виртуальный глаз»: то же смещение, что получило оружие, применяется к глазу.
            -- Оптика видит оружие всегда по оси (нет эффекта луны), картинка идёт за оружием.
            local Mn = Matrix()
            Mn:SetTranslation(nomP)
            Mn:SetAngles(nomA)
            -- только для оптики с увеличением; коллиматоры и механика рисуются от реальной камеры
            local useVE = cv.optic_virtual_eye:GetBool() and TFPBC.Motion and TFPBC.Motion.IsOpticScope
                and TFPBC.Motion.IsOpticScope(wpn)
            local inv = useVE and Mn:GetInverse() or nil
            if inv then
                local Md = Matrix()
                Md:SetTranslation(vp)
                Md:SetAngles(va)
                local Mr = Matrix()
                Mr:SetTranslation(pos)
                Mr:SetAngles(ang)
                local Mv = Md * inv * Mr
                wpn.TFP_VEyePos, wpn.TFP_VEyeAng = Mv:GetTranslation(), Mv:GetAngles()
            else
                wpn.TFP_VEyePos, wpn.TFP_VEyeAng = nil, nil
            end
        else
            wpn.TFP_VMPos = nil
            wpn.TFP_VEyePos, wpn.TFP_VEyeAng = nil, nil
        end
    else
        wpn.TFP_VMPos = nil
    end
    return fov
end

function TFPBC.OnInactive(ply)
    local wpn = IsValid(ply) and ply:GetActiveWeapon()
    if not IsValid(wpn) or not wpn.ARC9 then return end
    wpn.TFP_VMPos = nil
    wpn.TFP_VEyePos, wpn.TFP_VEyeAng = nil, nil
    if wpn.TFP_OrigNoBob ~= nil then
        wpn.NoViewBob = wpn.TFP_OrigNoBob
        wpn.TFP_OrigNoBob = nil
    end
    if wpn.TFP_ForcedExp then
        wpn.RTScopeNew_ForceExpensive = nil
        wpn.TFP_ForcedExp = nil
    end
    if IsValid(wpn.RTScopeModel) and wpn.RTScopeModel.TFP_IsWM then
        wpn.RTScopeModel = nil
    end
end

-- ============================================================ 2. RT-оптика
local RT = { failed = false, expCalls = 0, cheapCalls = 0, installed = 0 }
TFPBC_RTOrig = TFPBC_RTOrig or {}

local function RTOn()
    if not ARC9_ENABLE_NEWSCOPES_MEOW or RT.failed then return false end
    if not cv.rt_enable:GetBool() then return false end
    return TFPBC.IsActive()
end

local function FindRTScopeModel(wpn)
    if wpn.RTScope and wpn.GetWM then
        local wm = wpn:GetWM()
        if IsValid(wm) then return wm end
    end
    if not istable(wpn.WModel) or not wpn.GetActiveSightSlotTable then return nil end
    local addr = wpn:GetActiveSightSlotTable().Address
    if not addr then return nil end
    for _, m in ipairs(wpn.WModel) do
        if IsValid(m) and not m.hidden and m.slottbl and m.slottbl.Address == addr then
            local at = m.atttbl or wpn:GetFinalAttTable(m.slottbl)
            if at and at.RTScope then return m end
        end
    end
end

local function RTName()
    local t = render.GetRenderTarget()
    return t and t:GetName() or ""
end

local function RTSafe(fn, ...)
    local before = RTName()
    local ok, err = pcall(fn, ...)
    if ok then return end
    ARC9.OverDraw = false
    ARC9.RTScopeRender = false
    for _ = 1, 4 do
        if RTName() == before then break end
        pcall(render.PopRenderTarget)
    end
    RT.failed = true
    ErrorNoHalt("[TrueFP] RT-оптика отключена из-за ошибки: " .. tostring(err) .. "\n  Включить заново: truefp_rtscope_reset\n")
end

-- пока ARC9 рендерит картинку/сетку прицела, подставляем «виртуальный глаз» (на оси оружия)
local function WithVirtualEye(wpn, fn, ...)
    local ep, ea = wpn.TFP_VEyePos, wpn.TFP_VEyeAng
    if not ep or not ea then return fn(...) end
    local o1, o2 = MainEyePos, MainEyeAngles
    MainEyePos = function() return ep end
    MainEyeAngles = function() return ea end
    local res = { pcall(fn, ...) }
    MainEyePos, MainEyeAngles = o1, o2
    if not res[1] then error(res[2], 0) end
    return unpack(res, 2)
end

local matCheap = Material("effects/arc9/rt_cheap")
local logNext = 0

local function RT_PreRender()
    local _, wpn = ARC9Weapon()
    if not wpn then return end
    if ARC9.OverDraw then ARC9.OverDraw = false; ARC9.RTScopeRender = false end
    local model = FindRTScopeModel(wpn)
    if IsValid(model) then model.TFP_IsWM = true end
    wpn.RTScopeModel = model
    if not IsValid(model) then return end
    if wpn.RunHook then wpn:RunHook("Hook_DoRT") end

    pcall(wpn.GetMagnification, wpn)
    local gsa = wpn:GetSightAmount()
    local okm, rtm = pcall(wpn.GetRTScopeMagnification, wpn)
    matCheap:SetFloat("$scale2", math.Clamp(gsa * 10, (okm and rtm and rtm > 3) and 1 or 0.5, 1))

    if cv.rt_expensive:GetBool() then
        local okz, z = pcall(wpn.GetRealZoom, wpn, wpn:GetSight())
        wpn.RTScopeNew_ForceExpensive = (okz and z and z > 1.05) or nil
        wpn.TFP_ForcedExp = true
    elseif wpn.TFP_ForcedExp then
        wpn.RTScopeNew_ForceExpensive = nil
        wpn.TFP_ForcedExp = nil
    end

    local cheap = wpn:IsCheapScope()
    if cv.debug:GetBool() and CurTime() >= logNext then
        logNext = CurTime() + 1
        print(string.format("[TrueFP] rt: cheap=%s drawingRN=%s sight=%.2f mag=%s exp=%d cheapCalls=%d",
            tostring(cheap), tostring(model.RTScopeDrawingRN), gsa, tostring(rtm), RT.expCalls, RT.cheapCalls))
    end
    if cheap then return end
    if model.RTScopeDrawingRN and not ARC9.OverDraw then
        RT.expCalls = RT.expCalls + 1
        RTSafe(WithVirtualEye, wpn, wpn.RenderRT, wpn, false, okm and rtm or 2)
    end
end

local function RT_PreDrawVMs()
    local _, wpn = ARC9Weapon()
    if not wpn or ARC9.OverDraw then return end
    local model = wpn.RTScopeModel
    if not IsValid(model) or not model.TFP_IsWM then return end
    if not wpn:IsCheapScope() then return end
    if model.RTScopeDrawingRN then
        RT.cheapCalls = RT.cheapCalls + 1
        RT.cheapFrame = FrameNumber()
        RTSafe(WithVirtualEye, wpn, wpn.RenderRT, wpn, true)
    end
end

local function RT_Screenspace()
    local _, wpn = ARC9Weapon()
    if not wpn or ARC9.OverDraw then return end
    local model = wpn.RTScopeModel
    if not IsValid(model) or not model.TFP_IsWM then return end
    local cheap = wpn:IsCheapScope()
    if cheap and model.RTScopeDrawingRN and RT.cheapFrame ~= FrameNumber() then
        RT.cheapCalls = RT.cheapCalls + 1
        RT.cheapFrame = FrameNumber()
        RTSafe(WithVirtualEye, wpn, wpn.RenderRT, wpn, true)
    end
    local atttbl = wpn:IsScoping()
    if not atttbl then return end
    RTSafe(WithVirtualEye, wpn, wpn.DrawRTReticle, wpn, model, atttbl, nil, cheap)
end

local function RT_Install()
    local list = {
        { "PreRender", "ARC9_PreRender", RT_PreRender },
        { "PreDrawViewModels", "ARC9_PreDrawViewModels", RT_PreDrawVMs },
        { "RenderScreenspaceEffects", "ARC9_PostDrawViewModels", RT_Screenspace },
    }
    local n = 0
    for _, h in ipairs(list) do
        local event, name, fn = h[1], h[2], h[3]
        local key = event .. "/" .. name
        local orig = TFPBC_RTOrig[key]
        if not orig then
            local t = hook.GetTable()[event]
            orig = t and t[name]
            TFPBC_RTOrig[key] = orig
        end
        if orig then
            hook.Add(event, name, function(...)
                if RTOn() then return fn(...) end
                return orig(...)
            end)
            n = n + 1
        end
    end
    RT.installed = n
end

hook.Add("InitPostEntity", "TFPBC_RTInstall", function()
    RT_Install()
    timer.Simple(5, function() if RT.installed < 3 then RT_Install() end end)
end)
if ARC9 and hook.GetTable()["PreRender"] and hook.GetTable()["PreRender"]["ARC9_PreRender"] then
    RT_Install()
end

concommand.Add("truefp_rtscope_reset", function()
    RT.failed = false
    print("[TrueFP] RT-оптика включена заново")
end)

-- ============================================================ 2b. руки (TPIK)
local function SyncWM(wpn)
    local wm = wpn:GetWM()
    if not IsValid(wm) or not wpn.TFP_VMPos then return end

    local pos = wpn.TFP_VMPos
    local ang = wpn.TFP_VMAng
    local sight = math.Clamp(wpn:GetSightAmount() or 0, 0, 1)

    local ply = wpn:GetOwner()
    if IsValid(ply) then
        pos = CalcHandOffset(ply, pos, ang, sight)
    end

    wm:SetPos(pos)
    wm:SetAngles(ang)
    wm:SetRenderOrigin(pos)
    wm:SetRenderAngles(ang)
    wm:SetupBones()

    -- Насадки (цевьё, рукоятки, грипы) ARC9 ставит на позицию только при отрисовке оружия, то есть ПОСЛЕ TPIK.
    -- Рука, которая держится за насадку, целилась в её позицию с прошлого кадра - отсюда отставание.
    -- Расставляем их по текущему кадру заранее.
    local list = wpn.WModel
    if istable(list) then
        for _, model in ipairs(list) do
            if model ~= wm and IsValid(model) and model.slottbl and not model.IsAnimationProxy
                and not model.charmparent and not model.hidden then
                local ok, apos, aang = pcall(wpn.GetAttachmentPos, wpn, model.slottbl, true, false, false, nil, angle_zero, model.Duplicate)
                if ok and apos and aang then
                    model:SetPos(apos)
                    model:SetAngles(aang)
                    model:SetRenderOrigin(apos)
                    model:SetRenderAngles(aang)
                    model:SetupBones()
                end
            end
        end
    end
end

local tpikNextCheck = 0
local function TPIK_Install()
    local key = "PrePlayerDraw/ARC9_TPIK"
    local orig = TFPBC_RTOrig[key]
    if not orig then
        local t = hook.GetTable()["PrePlayerDraw"]
        orig = t and t["ARC9_TPIK"]
        TFPBC_RTOrig[key] = orig
    end
    if not orig then return false end
    hook.Add("PrePlayerDraw", "ARC9_TPIK", function(ply, flags)
        -- Contact IK держит левую руку: TPIK её пропускает
        if TFPBC.ContactTPIKSkip then TFPBC.ContactTPIKSkip(ply) end
        if ply == LocalPlayer() and cv.tpik_fix:GetBool() and TFPBC.IsActive() then
            local wpn = ply:GetActiveWeapon()
            if IsValid(wpn) and wpn.ARC9 then
                if CurTime() >= tpikNextCheck then
                    tpikNextCheck = CurTime() + 2
                    local c = GetConVar("arc9_tpik_framerate_local")
                    if c and c:GetInt() < 150 then RunConsoleCommand("arc9_tpik_framerate_local", "150") end
                end
                SyncWM(wpn)
                local realFT = RealFrameTime
                RealFrameTime = function() return 10 end
                local ok, err = pcall(orig, ply, flags)
                RealFrameTime = realFT
                if not ok then ErrorNoHalt("[TrueFP] TPIK: " .. tostring(err) .. "\n") end
                return
            end
        end
        return orig(ply, flags)
    end)
    return true
end

-- ============================================================ 3. коллиматоры
local white = Color(255, 255, 255)
local nextErr = 0

local function HoloBody(wpn, mdl, atttbl)
    local ref = (atttbl.ID or 56) % 63
    render.UpdateScreenEffectTexture()
    render.SetStencilEnable(true)
    render.SetStencilCompareFunction(STENCIL_ALWAYS)
    render.SetStencilPassOperation(STENCIL_REPLACE)
    render.SetStencilFailOperation(STENCIL_KEEP)
    render.SetStencilZFailOperation(STENCIL_REPLACE)
    render.SetStencilWriteMask(255)
    render.SetStencilTestMask(255)
    render.SetBlend(0)
    render.SetStencilReferenceValue(bit.bor(ref, 64))
    mdl:DrawModel()
    render.SetBlend(1)
    render.SetStencilPassOperation(STENCIL_KEEP)
    render.SetStencilCompareFunction(STENCIL_EQUAL)

    local sight = wpn:GetSight()
    local reticle = sight.Reticle or atttbl.HoloSightReticle
    wpn:SetHoloSightRenderDepth(mdl, atttbl.HoloSightDepthAdjustment)
    if not reticle then return end

    local vs = render.GetViewSetup and render.GetViewSetup()
    local origin = (vs and vs.origin) or EyePos()
    local angg = mdl:GetAngles()
    if mdl.FakeHolosightAngleOffset then
        origin = origin + (angg + mdl.FakeHolosightAngleOffset):Forward() * 9000
        angg.z = angg.z - sight.Ang.z
    else
        origin = origin + angg:Forward() * 9000
    end
    local s = atttbl.HoloSightSize * cv.holo_scale:GetFloat()
    local col = atttbl.HoloSightColor or white
    if atttbl.HoloSightColorable then
        local r, g, b = GetConVar("arc9_reflex_r"), GetConVar("arc9_reflex_g"), GetConVar("arc9_reflex_b")
        if r and g and b then col = Color(r:GetFloat(), g:GetFloat(), b:GetFloat()) end
    end
    render.SetMaterial(reticle)
    local up, right = angg:Up(), angg:Right()
    local v1 = origin + (up * s / 2) - (right * s / 2)
    local v2 = origin + (up * s / 2) + (right * s / 2)
    local v3 = origin - (up * s / 2) + (right * s / 2)
    local v4 = origin - (up * s / 2) - (right * s / 2)
    render.DrawQuad(v1, v2, v3, v4, col)
    if atttbl.HoloSightFunc then atttbl.HoloSightFunc(wpn, origin, mdl) end
    if atttbl.HoloSightEzFunc then atttbl.HoloSightEzFunc(wpn, v1, v2, v3, v4, col) end
end

local function DrawHolo(wpn, mdl, atttbl)
    if wpn:GetSightAmount() <= 0 and not wpn:GetCustomize() and not atttbl.HoloSightAlwaysOn then return end
    if ARC9.OverDraw then return end
    local owner = wpn:GetOwner()
    if owner ~= LocalPlayer() or owner.ARC9NoScopes then return end
    if not wpn.SetHoloSightRenderDepth or not wpn.GetSight then return end
    wpn.RenderingHolosight = true
    local prevFog = render.GetFogMode and render.GetFogMode()
    if prevFog then render.FogMode(MATERIAL_FOG_NONE) end
    local ok, err = pcall(HoloBody, wpn, mdl, atttbl)
    if prevFog then render.FogMode(prevFog) end
    render.DepthRange(0, 1)
    render.SetStencilWriteMask(255)
    render.SetStencilTestMask(255)
    render.SetStencilEnable(false)
    if not ok and CurTime() >= nextErr then
        nextErr = CurTime() + 2
        ErrorNoHalt("[TrueFP] коллиматор: " .. tostring(err) .. "\n")
    end
end

hook.Add("PostDrawTranslucentRenderables", "TFPBC_Holo", function()
    if not TFPBC.IsActive() then return end
    local _, wpn = ARC9Weapon()
    if not wpn or not wpn.DoHolosight or not istable(wpn.WModel) then return end
    local native = cv.holo_native:GetBool()
    for _, model in ipairs(wpn.WModel) do
        if IsValid(model) and not model.hidden then
            local atttbl = model.atttbl
            if atttbl and atttbl.HoloSight then
                if native or not atttbl.HoloSightSize then
                    wpn:DoHolosight(model, atttbl)
                else
                    DrawHolo(wpn, model, atttbl)
                end
            end
        end
    end
end)

-- ============================================================ отладка
concommand.Add("truefp_debug_info", function()
    local ply, wpn = ARC9Weapon()
    print("[TrueFP] active=" .. tostring(TFPBC.IsActive())
        .. " fov=" .. cv.fov:GetFloat()
        .. " wm=" .. cv.wm_x:GetFloat() .. "," .. cv.wm_y:GetFloat() .. "," .. cv.wm_z:GetFloat()
        .. " wm_run_z=" .. cv.wm_run_z:GetFloat())
    if not wpn then print("[TrueFP] нет ARC9-оружия в руках") return end
    print("[TrueFP] weapon=" .. wpn:GetClass()
        .. " sight=" .. string.format("%.2f", wpn:GetSightAmount()))
end)

hook.Add("InitPostEntity", "TFPBC_TPIKInstall", function()
    TPIK_Install()
    timer.Simple(5, function() if not TFPBC_TPIKOk then TFPBC_TPIKOk = TPIK_Install() end end)
end)
if ARC9 and hook.GetTable()["PrePlayerDraw"] and hook.GetTable()["PrePlayerDraw"]["ARC9_TPIK"] then
    TFPBC_TPIKOk = TPIK_Install()
end