if not CLIENT then return end

-- ==============================
-- CONVARS
-- ==============================
local cvars = {
    -- Toggles
    straight = CreateClientConVar("arc9_bf_straight_enable", "1", true, false),
    left = CreateClientConVar("arc9_bf_left_enable", "1", true, false),
    right = CreateClientConVar("arc9_bf_right_enable", "1", true, false),

    -- Viewmodel offsets
    straight_x = CreateClientConVar("arc9_bf_straight_x", "5.5", true, false),
    straight_y = CreateClientConVar("arc9_bf_straight_y", "0", true, false),
    straight_z = CreateClientConVar("arc9_bf_straight_z", "2.6", true, false),
    straight_pitch = CreateClientConVar("arc9_bf_straight_pitch", "0", true, false),
    straight_yaw = CreateClientConVar("arc9_bf_straight_yaw", "0", true, false),
    straight_roll = CreateClientConVar("arc9_bf_straight_roll", "-50.2", true, false),

    left_x = CreateClientConVar("arc9_bf_left_x", "-9.8", true, false),
    left_y = CreateClientConVar("arc9_bf_left_y", "0", true, false),
    left_z = CreateClientConVar("arc9_bf_left_z", "2.2", true, false),
    left_pitch = CreateClientConVar("arc9_bf_left_pitch", "0", true, false),
    left_yaw = CreateClientConVar("arc9_bf_left_yaw", "0", true, false),
    left_roll = CreateClientConVar("arc9_bf_left_roll", "-11.7", true, false),

    right_x = CreateClientConVar("arc9_bf_right_x", "4.8", true, false),
    right_y = CreateClientConVar("arc9_bf_right_y", "0", true, false),
    right_z = CreateClientConVar("arc9_bf_right_z", "2.2", true, false),
    right_pitch = CreateClientConVar("arc9_bf_right_pitch", "0", true, false),
    right_yaw = CreateClientConVar("arc9_bf_right_yaw", "0", true, false),
    right_roll = CreateClientConVar("arc9_bf_right_roll", "8.9", true, false),

    -- Laser offsets (manual fine-tune – optional)
    straight_lx = CreateClientConVar("arc9_bf_straight_lx", "0", true, false),
    straight_ly = CreateClientConVar("arc9_bf_straight_ly", "0", true, false),
    straight_lz = CreateClientConVar("arc9_bf_straight_lz", "0", true, false),

    left_lx = CreateClientConVar("arc9_bf_left_lx", "0", true, false),
    left_ly = CreateClientConVar("arc9_bf_left_ly", "0", true, false),
    left_lz = CreateClientConVar("arc9_bf_left_lz", "0", true, false),

    right_lx = CreateClientConVar("arc9_bf_right_lx", "0", true, false),
    right_ly = CreateClientConVar("arc9_bf_right_ly", "0", true, false),
    right_lz = CreateClientConVar("arc9_bf_right_lz", "0", true, false),

    -- Laser global settings
    laser_enable = CreateClientConVar("arc9_muzzle_laser_enable", "1", true, false),
    laser_visible = CreateClientConVar("arc9_muzzle_laser_visible", "0", true, false),

    -- Scope behavior
    scope_mode = CreateClientConVar("arc9_bf_scope_mode", "2", true, false),
    disable_on_aim = CreateClientConVar("arc9_bf_disable_on_aim", "0", true, false),

    -- Third person / worldmodel
    wm_enable = CreateClientConVar("arc9_bf_worldmodel", "1", true, false),
    wm_others = CreateClientConVar("arc9_bf_worldmodel_others", "1", true, false),

    wm_straight_x = CreateClientConVar("arc9_bf_wm_straight_x", "5.5", true, false),
    wm_straight_y = CreateClientConVar("arc9_bf_wm_straight_y", "0", true, false),
    wm_straight_z = CreateClientConVar("arc9_bf_wm_straight_z", "2.6", true, false),
    wm_straight_p = CreateClientConVar("arc9_bf_wm_straight_pitch", "0", true, false),
    wm_straight_yw = CreateClientConVar("arc9_bf_wm_straight_yaw", "0", true, false),
    wm_straight_r = CreateClientConVar("arc9_bf_wm_straight_roll", "-50.2", true, false),

    wm_left_x = CreateClientConVar("arc9_bf_wm_left_x", "-9.8", true, false),
    wm_left_y = CreateClientConVar("arc9_bf_wm_left_y", "0", true, false),
    wm_left_z = CreateClientConVar("arc9_bf_wm_left_z", "2.2", true, false),
    wm_left_p = CreateClientConVar("arc9_bf_wm_left_pitch", "0", true, false),
    wm_left_yw = CreateClientConVar("arc9_bf_wm_left_yaw", "0", true, false),
    wm_left_r = CreateClientConVar("arc9_bf_wm_left_roll", "-11.7", true, false),

    wm_right_x = CreateClientConVar("arc9_bf_wm_right_x", "4.8", true, false),
    wm_right_y = CreateClientConVar("arc9_bf_wm_right_y", "0", true, false),
    wm_right_z = CreateClientConVar("arc9_bf_wm_right_z", "2.2", true, false),
    wm_right_p = CreateClientConVar("arc9_bf_wm_right_pitch", "0", true, false),
    wm_right_yw = CreateClientConVar("arc9_bf_wm_right_yaw", "0", true, false),
    wm_right_r = CreateClientConVar("arc9_bf_wm_right_roll", "8.9", true, false),
}

local function apply(wep)
    if not IsValid(wep) or not wep.CanBlindFire then return end

    wep.BlindFireStraight = cvars.straight:GetBool()
    wep.BlindFireLeft = cvars.left:GetBool()
    wep.BlindFireRight = cvars.right:GetBool()

    wep.BlindFirePos = Vector(cvars.straight_x:GetFloat(), cvars.straight_y:GetFloat(), cvars.straight_z:GetFloat())
    wep.BlindFireAng = Angle(cvars.straight_pitch:GetFloat(), cvars.straight_yaw:GetFloat(), cvars.straight_roll:GetFloat())
    wep.BlindFireLeftPos = Vector(cvars.left_x:GetFloat(), cvars.left_y:GetFloat(), cvars.left_z:GetFloat())
    wep.BlindFireLeftAng = Angle(cvars.left_pitch:GetFloat(), cvars.left_yaw:GetFloat(), cvars.left_roll:GetFloat())
    wep.BlindFireRightPos = Vector(cvars.right_x:GetFloat(), cvars.right_y:GetFloat(), cvars.right_z:GetFloat())
    wep.BlindFireRightAng = Angle(cvars.right_pitch:GetFloat(), cvars.right_yaw:GetFloat(), cvars.right_roll:GetFloat())

    wep.BlindFireLaserOff = Vector(cvars.straight_lx:GetFloat(), cvars.straight_ly:GetFloat(), cvars.straight_lz:GetFloat())
    wep.BlindFireLeftLaserOff = Vector(cvars.left_lx:GetFloat(), cvars.left_ly:GetFloat(), cvars.left_lz:GetFloat())
    wep.BlindFireRightLaserOff = Vector(cvars.right_lx:GetFloat(), cvars.right_ly:GetFloat(), cvars.right_lz:GetFloat())

    wep.BlindFireWMPos = Vector(cvars.wm_straight_x:GetFloat(), cvars.wm_straight_y:GetFloat(), cvars.wm_straight_z:GetFloat())
    wep.BlindFireWMAng = Angle(cvars.wm_straight_p:GetFloat(), cvars.wm_straight_yw:GetFloat(), cvars.wm_straight_r:GetFloat())
    wep.BlindFireWMLeftPos = Vector(cvars.wm_left_x:GetFloat(), cvars.wm_left_y:GetFloat(), cvars.wm_left_z:GetFloat())
    wep.BlindFireWMLeftAng = Angle(cvars.wm_left_p:GetFloat(), cvars.wm_left_yw:GetFloat(), cvars.wm_left_r:GetFloat())
    wep.BlindFireWMRightPos = Vector(cvars.wm_right_x:GetFloat(), cvars.wm_right_y:GetFloat(), cvars.wm_right_z:GetFloat())
    wep.BlindFireWMRightAng = Angle(cvars.wm_right_p:GetFloat(), cvars.wm_right_yw:GetFloat(), cvars.wm_right_r:GetFloat())
end

local cache = {}
local applied = setmetatable({}, { __mode = "k" })

hook.Add("Think", "ARC9_BF_OptionsApply", function()
    local changed = false
    for k, cv in pairs(cvars) do
        local v = cv:GetString()
        if cache[k] ~= v then cache[k] = v; changed = true end
    end

    if changed then applied = setmetatable({}, { __mode = "k" }) end

    -- every player needs the values, their world models are posed on our machine
    for _, ply in ipairs(player.GetAll()) do
        local wep = ply:GetActiveWeapon()
        if IsValid(wep) and wep.CanBlindFire and not applied[wep] then
            applied[wep] = true
            apply(wep)
        end
    end
end)

-- ==============================
-- MENU ENTRY 1: BLINDFIRE (Toggles + Viewmodel)
-- ==============================
hook.Add("PopulateToolMenu", "ARC9_Blindfire_Viewmodel", function()
    spawnmenu.AddToolMenuOption("Options", "ARC9", "ARC9_Blindfire", "Blindfire", "", "", function(panel)
        panel:ClearControls()

        panel:Help("Enable / Disable Blindfire Directions")
        panel:CheckBox("Straight (Alt+W)", "arc9_bf_straight_enable")
        panel:CheckBox("Left (Alt+A)", "arc9_bf_left_enable")
        panel:CheckBox("Right (Alt+D)", "arc9_bf_right_enable")

        panel:Help("Scope Behavior")
        panel:NumSlider("Scope Mode", "arc9_bf_scope_mode", 0, 2, 0)
        panel:ControlHelp("0=Never disable, 1=Disable with non-PIP (flat) scopes, 2=Disable with all scopes")
        panel:CheckBox("Disable while aiming (any sight)", "arc9_bf_disable_on_aim")
        panel:ControlHelp("When checked, blindfire is disabled whenever you aim down sights, regardless of scope type.")

        panel:Help("Aiming")
        panel:CheckBox("Muzzle-Accurate Aiming", "arc9_muzzle_laser_enable")
        panel:ControlHelp("When off, shots aim from your eyes like normal ARC9 fire instead of tracking the real muzzle direction.")
        panel:CheckBox("Show Laser Beam (debug)", "arc9_muzzle_laser_visible")
        panel:ControlHelp("Draws the traced beam and hit marker - useful for checking alignment, purely visual. Off by default.")
        panel:NumSlider("Aim Update Rate", "arc9_bf_muzzle_netrate", 10, 120, 0)
        panel:ControlHelp("How often the muzzle aim point is sent to the server. The trace and the laser always run at your full framerate; this only costs bandwidth.")

        panel:Help("Third Person / World Model")
        panel:CheckBox("Pose the world model too", "arc9_bf_worldmodel")
        panel:ControlHelp("Applies the blindfire pose to the held world model, so it works in third person. The arms follow the gun through ARC9's TPIK.")
        panel:CheckBox("Show other players blindfiring", "arc9_bf_worldmodel_others")

        panel:Help("World Model Offsets - Straight")
        panel:NumSlider("X", "arc9_bf_wm_straight_x", -50, 50, 1)
        panel:NumSlider("Y", "arc9_bf_wm_straight_y", -50, 50, 1)
        panel:NumSlider("Z", "arc9_bf_wm_straight_z", -50, 50, 1)
        panel:NumSlider("Pitch", "arc9_bf_wm_straight_pitch", -90, 90, 1)
        panel:NumSlider("Yaw", "arc9_bf_wm_straight_yaw", -90, 90, 1)
        panel:NumSlider("Roll", "arc9_bf_wm_straight_roll", -90, 90, 1)

        panel:Help("World Model Offsets - Left")
        panel:NumSlider("X", "arc9_bf_wm_left_x", -50, 50, 1)
        panel:NumSlider("Y", "arc9_bf_wm_left_y", -50, 50, 1)
        panel:NumSlider("Z", "arc9_bf_wm_left_z", -50, 50, 1)
        panel:NumSlider("Pitch", "arc9_bf_wm_left_pitch", -90, 90, 1)
        panel:NumSlider("Yaw", "arc9_bf_wm_left_yaw", -90, 90, 1)
        panel:NumSlider("Roll", "arc9_bf_wm_left_roll", -90, 90, 1)

        panel:Help("World Model Offsets - Right")
        panel:NumSlider("X", "arc9_bf_wm_right_x", -50, 50, 1)
        panel:NumSlider("Y", "arc9_bf_wm_right_y", -50, 50, 1)
        panel:NumSlider("Z", "arc9_bf_wm_right_z", -50, 50, 1)
        panel:NumSlider("Pitch", "arc9_bf_wm_right_pitch", -90, 90, 1)
        panel:NumSlider("Yaw", "arc9_bf_wm_right_yaw", -90, 90, 1)
        panel:NumSlider("Roll", "arc9_bf_wm_right_roll", -90, 90, 1)

        panel:Help("Viewmodel Offsets – Straight")
        panel:NumSlider("X", "arc9_bf_straight_x", -50, 50, 1)
        panel:NumSlider("Y", "arc9_bf_straight_y", -50, 50, 1)
        panel:NumSlider("Z", "arc9_bf_straight_z", -50, 50, 1)
        panel:NumSlider("Pitch", "arc9_bf_straight_pitch", -90, 90, 1)
        panel:NumSlider("Yaw", "arc9_bf_straight_yaw", -90, 90, 1)
        panel:NumSlider("Roll", "arc9_bf_straight_roll", -90, 90, 1)

        panel:Help("Viewmodel Offsets – Left")
        panel:NumSlider("X", "arc9_bf_left_x", -50, 50, 1)
        panel:NumSlider("Y", "arc9_bf_left_y", -50, 50, 1)
        panel:NumSlider("Z", "arc9_bf_left_z", -50, 50, 1)
        panel:NumSlider("Pitch", "arc9_bf_left_pitch", -90, 90, 1)
        panel:NumSlider("Yaw", "arc9_bf_left_yaw", -90, 90, 1)
        panel:NumSlider("Roll", "arc9_bf_left_roll", -90, 90, 1)

        panel:Help("Viewmodel Offsets – Right")
        panel:NumSlider("X", "arc9_bf_right_x", -50, 50, 1)
        panel:NumSlider("Y", "arc9_bf_right_y", -50, 50, 1)
        panel:NumSlider("Z", "arc9_bf_right_z", -50, 50, 1)
        panel:NumSlider("Pitch", "arc9_bf_right_pitch", -90, 90, 1)
        panel:NumSlider("Yaw", "arc9_bf_right_yaw", -90, 90, 1)
        panel:NumSlider("Roll", "arc9_bf_right_roll", -90, 90, 1)
    end)
end)

timer.Simple(0.5, function()
    local ply = LocalPlayer()
    if IsValid(ply) then
        local wep = ply:GetActiveWeapon()
        if IsValid(wep) and wep.CanBlindFire then
            apply(wep)
        end
    end
end)