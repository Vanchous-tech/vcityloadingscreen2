SWEP.CanBlindFire = true
SWEP.BlindFireStraight = true
SWEP.BlindFireLeft = true
SWEP.BlindFireRight = true

SWEP.BlindFirePos = Vector(5.5, 0, 2.6)
SWEP.BlindFireAng = Angle(0, 0, -50.2)

SWEP.BlindFireLeftPos = Vector(-9.8, 0, 2.2)
SWEP.BlindFireLeftAng = Angle(0, 0, -11.7)

SWEP.BlindFireRightPos = Vector(4.8, 0, 2.2)
SWEP.BlindFireRightAng = Angle(0, 0, 8.9)

SWEP.BlindFireLaserOff = Vector(0, 0, 0)
SWEP.BlindFireLeftLaserOff = Vector(0, 0, 0)
SWEP.BlindFireRightLaserOff = Vector(0, 0, 0)

SWEP.BlindFiring = false
SWEP.BlindFireDirection = 0
SWEP.BlindFireOffsetPos = Vector(0, 0, 0)
SWEP.BlindFireOffsetAng = Angle(0, 0, 0)
SWEP.BlindFireAimOffsetAng = Angle(0, 0, 0)

-- third person / worldmodel pose (hand-bone space, same slots as WorldModelOffset)
SWEP.BlindFireWMPos = Vector(5.5, 0, 2.6)
SWEP.BlindFireWMAng = Angle(0, 0, -50.2)

SWEP.BlindFireWMLeftPos = Vector(-9.8, 0, 2.2)
SWEP.BlindFireWMLeftAng = Angle(0, 0, -11.7)

SWEP.BlindFireWMRightPos = Vector(4.8, 0, 2.2)
SWEP.BlindFireWMRightAng = Angle(0, 0, 8.9)
