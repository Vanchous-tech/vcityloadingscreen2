-- TrueFP Bodycam: серверная часть
--  1) отдаёт клиентам файлы аддона (без этого в мультиплеере include() не находит файлы)
--  2) ретранслирует движения оружия другим игрокам
for _, f in ipairs({
    "truefp_bodycam/cl_core.lua",
    "truefp_bodycam/cl_motion.lua",
    "truefp_bodycam/cl_arc9.lua",
    "truefp_bodycam/cl_netsync.lua",
    "truefp_bodycam/cl_contactik.lua",
    "truefp_bodycam/cl_menu.lua",
}) do
    AddCSLuaFile(f)
end

util.AddNetworkString("TFPBC_Motion")

local last = {}

net.Receive("TFPBC_Motion", function(_, ply)
    if not IsValid(ply) then return end
    local now = CurTime()
    if (last[ply] or 0) > now - 0.03 then return end   -- не чаще ~30 раз/сек
    last[ply] = now

    local on = net.ReadBool()
    net.Start("TFPBC_Motion", true)
    net.WriteUInt(ply:EntIndex(), 8)
    net.WriteBool(on)
    if on then
        for _ = 1, 12 do net.WriteInt(net.ReadInt(16), 16) end
    end
    net.SendOmit(ply)
end)

hook.Add("PlayerDisconnected", "TFPBC_MotionCleanup", function(ply) last[ply] = nil end)
