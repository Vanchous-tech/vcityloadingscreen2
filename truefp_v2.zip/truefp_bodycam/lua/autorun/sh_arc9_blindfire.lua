-- ARC9 Blindfire – Perfect barrel alignment + calibration (Alt+T)
-- Scope behavior: 0=never disable, 1=disable with non-PIP scopes, 2=disable with all scopes
-- disableOnAim: 0=off, 1=disable blindfire when aiming (any sight)

if SERVER then
    AddCSLuaFile()
    util.AddNetworkString("ARC9_BlindFire_State")
    util.AddNetworkString("ARC9_Muzzle_Target")
    util.AddNetworkString("ARC9_BlindFire_Sync")
end

-- ==============================
-- HELPERS
-- ==============================
local function LerpVector(a, v1, v2)
    local d = v2 - v1
    return v1 + (a * d)
end

local function LerpAngle(a, v1, v2)
    local v11, v12, v13 = v1[1], v1[2], v1[3]
    local v21, v22, v23 = v2[1], v2[2], v2[3]
    local d1 = math.AngleDifference(v21, v11)
    local d2 = math.AngleDifference(v22, v12)
    local d3 = math.AngleDifference(v23, v13)
    return Angle(v11 + (a * d1), v12 + (a * d2), v13 + (a * d3))
end

local function getPosOffset(wep)
    local dir = wep.BlindFireDirection or 0
    if dir < 0 then
        return wep.BlindFireLeftPos or Vector(-9.5, 0, -1.2)
    elseif dir > 0 then
        return wep.BlindFireRightPos or Vector(5.5, 0, 20)
    end
    return wep.BlindFirePos or Vector(-1.3, 0, 5.8)
end

local function getVisualAngOffset(wep)
    local dir = wep.BlindFireDirection or 0
    if dir < 0 then
        return wep.BlindFireLeftAng or Angle(0, 10, -30)
    elseif dir > 0 then
        return wep.BlindFireRightAng or Angle(1, 0, 13.5)
    end
    return wep.BlindFireAng or Angle(0, 0, -53)
end

local function getLaserOffset(wep)
    local dir = wep.BlindFireDirection or 0
    if dir < 0 then
        return wep.BlindFireLeftLaserOff or Vector(0, 0, 0)
    elseif dir > 0 then
        return wep.BlindFireRightLaserOff or Vector(0, 0, 0)
    end
    return wep.BlindFireLaserOff or Vector(0, 0, 0)
end

-- worldmodel (third person) pose, in the same hand-bone space as SWEP.WorldModelOffset
local function getWMPosOffset(wep)
    local dir = wep.BlindFireDirection or 0
    if dir < 0 then
        return wep.BlindFireWMLeftPos or wep.BlindFireLeftPos or vector_origin
    elseif dir > 0 then
        return wep.BlindFireWMRightPos or wep.BlindFireRightPos or vector_origin
    end
    return wep.BlindFireWMPos or wep.BlindFirePos or vector_origin
end

local function getWMAngOffset(wep)
    local dir = wep.BlindFireDirection or 0
    if dir < 0 then
        return wep.BlindFireWMLeftAng or wep.BlindFireLeftAng or angle_zero
    elseif dir > 0 then
        return wep.BlindFireWMRightAng or wep.BlindFireRightAng or angle_zero
    end
    return wep.BlindFireWMAng or wep.BlindFireAng or angle_zero
end

-- ==============================
-- CONVARS (defined early, before any functions that use them)
-- ==============================
local muzzleEnable = CreateConVar("arc9_muzzle_hitscan_enable", "1", bit.bor(FCVAR_ARCHIVE, FCVAR_REPLICATED), "Fire hitscan from the real muzzle attachment instead of the eyes")
local muzzleForward = CreateConVar("arc9_muzzle_offset_forward", "28", bit.bor(FCVAR_ARCHIVE, FCVAR_REPLICATED), "Fallback muzzle offset forward from eyes, in units")
local muzzleRight = CreateConVar("arc9_muzzle_offset_right", "4", bit.bor(FCVAR_ARCHIVE, FCVAR_REPLICATED), "Fallback muzzle offset right from eyes, in units")
local muzzleUp = CreateConVar("arc9_muzzle_offset_up", "-5", bit.bor(FCVAR_ARCHIVE, FCVAR_REPLICATED), "Fallback muzzle offset up from eyes, in units")

local laserEnable = CreateConVar("arc9_muzzle_laser_enable", "1", bit.bor(FCVAR_ARCHIVE, FCVAR_REPLICATED), "Aim shots using the real muzzle-traced target point instead of the eyes")
local laserVisible = CreateConVar("arc9_muzzle_laser_visible", "0", bit.bor(FCVAR_ARCHIVE, FCVAR_REPLICATED), "Show laser beam and hit marker")
local muzzleViewModelFOVFix = CreateConVar("arc9_muzzle_vm_fov_fix", "1", FCVAR_ARCHIVE, "Compensate muzzle traces for the separate viewmodel FOV")
local smoothSpeed = CreateConVar("arc9_bf_smooth_speed", "12", bit.bor(FCVAR_ARCHIVE, FCVAR_REPLICATED), "Blindfire transition speed")
local scopeMode = CreateConVar("arc9_bf_scope_mode", "2", bit.bor(FCVAR_ARCHIVE, FCVAR_REPLICATED), "Blindfire scope behavior: 0=never disable, 1=disable with non-PIP scopes, 2=disable with all scopes")
local disableOnAim = CreateConVar("arc9_bf_disable_on_aim", "0", bit.bor(FCVAR_ARCHIVE, FCVAR_REPLICATED), "Disable blindfire entirely when aiming down sights (0=off, 1=on)")
local wmEnable = CreateConVar("arc9_bf_worldmodel", "1", bit.bor(FCVAR_ARCHIVE, FCVAR_REPLICATED), "Apply the blindfire pose to the world model / third person too")
local wmOthers = CreateConVar("arc9_bf_worldmodel_others", "1", bit.bor(FCVAR_ARCHIVE, FCVAR_REPLICATED), "Show other players' blindfire poses")
    local muzzleRate = CreateConVar("arc9_bf_muzzle_netrate", "120", bit.bor(FCVAR_ARCHIVE, FCVAR_REPLICATED), "How many times a second the muzzle aim point is sent to the server. The trace and the laser always run at full framerate.")
    local muzzleMouseTest = CreateConVar("arc9_muzzle_mouse3_test", "0", FCVAR_ARCHIVE, "Hold Mouse3 to freeze the camera and aim the viewmodel with the mouse")
    local muzzleTestActive = false
    local muzzleTestCameraAng
    local muzzleTestAimAng = Angle(0, 0, 0)

-- ==============================
-- SCOPE DETECTION
-- ==============================
local function ShouldDisableScoped(wep)
    if not IsValid(wep) then return false end

    -- If "disable on aim" is on, disable whenever aiming (any sight)
    if disableOnAim:GetBool() and wep:GetInSights() then
        return true
    end

    local mode = scopeMode:GetInt()
    if mode == 0 then return false end

    if not wep:GetInSights() then return false end

    local sight = wep:GetSight()
    if not sight or not sight.atttbl then return false end

    local isRT = sight.atttbl.RTScope or sight.atttbl.RTScopeNew or false
    local isFlat = sight.atttbl.FlatScope or false

    if mode == 1 then
        return isFlat
    elseif mode == 2 then
        return isRT or isFlat
    end

    return false
end

if CLIENT then
    cvars.AddChangeCallback("arc9_muzzle_laser_enable", function(_, _, new)
        if tobool(new) then return end
        local ply = LocalPlayer()
        if not IsValid(ply) then return end
        local wep = ply:GetActiveWeapon()
        if not IsValid(wep) or not wep.ARC9 then return end
        wep.MuzzleOriginPos = nil
        wep.MuzzleTargetPos = nil
        wep.MuzzleDirection = nil
        wep._ML_LastSentOrigin = nil
        wep._ML_LastSentDirection = nil
        net.Start("ARC9_Muzzle_Target")
        net.WriteBool(false)
        net.SendToServer()
    end, "ARC9_BlindFire_LaserToggleCleanup")
end

-- The muzzle lives on the viewmodel in first person and on the (mirrored) world
-- model in third person - the viewmodel is not being animated while you can see
-- your own body, so its attachments would be stale.
local function getMuzzleAttachment(wep)
    local owner = wep:GetOwner()
    if not (CLIENT and IsValid(owner) and owner == LocalPlayer()) then return nil end

    local muzzQCA = wep.GetQCAMuzzle and wep:GetQCAMuzzle()
    if not muzzQCA then return nil end

    -- ARC9's third person can leave ShouldDrawLocalPlayer false while still
    -- drawing the player, so ask ARC9 as well - otherwise the muzzle is read off
    -- the viewmodel and shots appear to come from in front of and below you
    local thirdperson = owner:ShouldDrawLocalPlayer()
        or (ARC9 and ARC9.ShouldThirdPerson and ARC9.ShouldThirdPerson()) or false

    local src

    if thirdperson then
        src = wep.GetWM and wep:GetWM()
        if not IsValid(src) then return nil end
        src:SetupBones()
    else
        src = owner:GetViewModel()
        if not IsValid(src) then return nil end
    end

        return src:GetAttachment(muzzQCA)
end
-- Apply only the lagger's post-ARC9 pose delta while aiming. The attachment
-- already includes ARC9's sight pose, so transforming from the camera pose would
-- apply the ADS offset twice.
local function applyAimedLaggerPose(wep, attach)
    local owner = wep:GetOwner()
    if not IsValid(owner) or owner:ShouldDrawLocalPlayer() then return attach end
    if ARC9 and ARC9.ShouldThirdPerson and ARC9.ShouldThirdPerson() then return attach end

    local sightAmount = wep.GetSightAmount and wep:GetSightAmount() or 0
    if sightAmount <= 0.001 then return attach end

    local pose = wep._BF_FinalViewModelPose
    if not pose or pose.frame < FrameNumber() - 1 then return attach end

    local localPos, localAng = WorldToLocal(attach.Pos, attach.Ang, pose.basePos, pose.baseAng)
    local worldPos, worldAng = LocalToWorld(localPos, localAng, pose.renderPos, pose.renderAng)
    return {Pos = worldPos, Ang = worldAng}
end
-- A viewmodel is rendered with a separate lens FOV. Convert its attachment
-- coordinates and bore direction into the player camera's projection so a
-- muzzle trace follows the barrel as it appears on screen at any ARC9 VM FOV.
local function applyViewModelFOVToMuzzle(wep, attach)
    if not muzzleViewModelFOVFix:GetBool() then return attach end

    local owner = wep:GetOwner()
    if not IsValid(owner) or owner:ShouldDrawLocalPlayer() then return attach end
    if ARC9 and ARC9.ShouldThirdPerson and ARC9.ShouldThirdPerson() then return attach end
    if not wep.GetViewModelFOV then return attach end

    -- ARC9 stores the actual current camera FOV here; it changes during ADS
    -- magnification while Player:GetFOV() may still report the unzoomed FOV.
    local viewFOV = wep._ARC9_ADSFOVCameraFOV or wep.FOV or owner:GetFOV()
    -- ARC9 caches the value it rendered with; avoid advancing its smoothing a
    -- second time by calling GetViewModelFOV from our per-frame trace.
    local modelFOV = wep.ViewModelFOV or wep.SmoothedViewModelFOV
    if not modelFOV then modelFOV = wep:GetViewModelFOV() end
    if not viewFOV or not modelFOV then return attach end

    -- The red debug beam is drawn by the world camera. Project its displayed
    -- start from the viewmodel lens into that camera, without moving the shot.
    local debugViewFOV = viewFOV
    local debugModelFOV = modelFOV
    if wep.WidescreenFix then
        debugModelFOV = wep:WidescreenFix(debugModelFOV)
    end
    debugViewFOV = math.Clamp(debugViewFOV, 1, 179)
    debugModelFOV = math.Clamp(debugModelFOV, 1, 179)
    local debugScale = math.tan(math.rad(debugViewFOV * 0.5)) / math.tan(math.rad(debugModelFOV * 0.5))

    -- Preserve the established shot-direction correction exactly.
    if wep.WidescreenFix then
        viewFOV = wep:WidescreenFix(viewFOV)
        modelFOV = wep:WidescreenFix(modelFOV)
    end

    viewFOV = math.Clamp(viewFOV, 1, 179)
    modelFOV = math.Clamp(modelFOV, 1, 179)
    local scale = math.tan(math.rad(viewFOV * 0.5)) / math.tan(math.rad(modelFOV * 0.5))
    if not isnumber(scale) or scale <= 0 then return attach end

    local cameraAng = EyeAngles()
    local forward, right, up = cameraAng:Forward(), cameraAng:Right(), cameraAng:Up()
    local pos = Vector(attach.Pos)
    local cameraPos = EyePos()
    local offset = pos - cameraPos
    local debugPos = cameraPos
        + forward * offset:Dot(forward)
        + right * (offset:Dot(right) * debugScale)
        + up * (offset:Dot(up) * debugScale)

    local bore = attach.Ang:Forward()
    local direction = (
        forward * bore:Dot(forward)
        + right * (bore:Dot(right) * scale)
        + up * (bore:Dot(up) * scale)
    ):GetNormalized()

    return {Pos = pos, VisualPos = debugPos, Ang = direction:Angle()}
end
-- SMOOTHING UPDATE
-- ==============================
local function UpdateBlindfireSmooth(wep)
    if not wep or not wep.CanBlindFire then return Vector(0,0,0), Angle(0,0,0) end

    wep._BF_SmoothPos = wep._BF_SmoothPos or Vector(0, 0, 0)
    wep._BF_SmoothAng = wep._BF_SmoothAng or Angle(0, 0, 0)

    local targetPos = wep.BlindFiring and getPosOffset(wep) or vector_origin
    local targetAng = wep.BlindFiring and getVisualAngOffset(wep) or angle_zero

    local speed = smoothSpeed:GetFloat()
    local frac = math.Clamp(FrameTime() * speed, 0, 1)
    wep._BF_SmoothPos = LerpVector(frac, wep._BF_SmoothPos, targetPos)
    wep._BF_SmoothAng = LerpAngle(frac, wep._BF_SmoothAng, targetAng)

    return wep._BF_SmoothPos, wep._BF_SmoothAng
end

-- ==============================
-- SHOT ORIGIN RESOLVER
-- ==============================
local function applyShotOrigin(wep, pos, ang)
    if not IsValid(wep) or not pos or not ang then return pos, ang end

    local muzzleOverride = false
    if laserEnable:GetBool() and wep.MuzzleOriginPos then
        pos = wep.MuzzleOriginPos
        muzzleOverride = true
    end

    if laserEnable:GetBool() and wep.MuzzleDirection then
        local dir = wep.MuzzleDirection
        if dir:LengthSqr() > 0.5 then
            ang = dir:Angle()
            ang.r = 0
            muzzleOverride = true
        end
    elseif laserEnable:GetBool() and wep.MuzzleTargetPos then
        local toTarget = wep.MuzzleTargetPos - pos
        if toTarget:LengthSqr() > 1 then
            ang = toTarget:Angle()
            ang.r = 0
            muzzleOverride = true
        end
    end

    -- ARC9 Tactical Deadzone rotates every player bullet after DoProjectileAttack.
    -- Our muzzle direction already contains the rendered deadzone pose, so undo
    -- that mod's cursor bend here; its EntityFireBullets hook then restores the
    -- exact muzzle ray instead of bending the shot a second time. Do the same
    -- for the spawn point because its hook rotates data.Src around the eye too.
    if muzzleOverride then
        local owner = wep:GetOwner()
        if IsValid(owner) then
            local pitch, yaw = 0, 0
            if CLIENT and owner == LocalPlayer() and isfunction(ARC9DZ_GetCursor) then
                pitch, yaw = ARC9DZ_GetCursor()
            elseif SERVER then
                pitch, yaw = owner.DZ_P or 0, owner.DZ_Y or 0
            end

            if pitch ~= 0 or yaw ~= 0 then
                local eyePos = owner:EyePos()
                local eyeAng = owner:EyeAngles()
                local deadzoneAng = eyeAng + Angle(pitch, yaw, 0)

                local localPos = WorldToLocal(pos, angle_zero, eyePos, deadzoneAng)
                pos = LocalToWorld(localPos, angle_zero, eyePos, eyeAng)

                local _, localAng = WorldToLocal(vector_origin, ang, vector_origin, deadzoneAng)
                _, ang = LocalToWorld(vector_origin, localAng, vector_origin, eyeAng)
            end
        end
    end

    return pos, ang
end

-- ==============================
-- VIEWMODEL OFFSET
-- ==============================
local function applyViewModelOffset(wep, pos, ang)
    if not pos or not ang then return pos, ang end

    -- If scoped and disabled, skip the offset entirely
    if ShouldDisableScoped(wep) then
        wep._BF_SmoothPos = Vector(0,0,0)
        wep._BF_SmoothAng = Angle(0,0,0)
        return pos, ang
    end

    local p, a = UpdateBlindfireSmooth(wep)

    if not wep.BlindFiring and p:LengthSqr() < 0.0001
        and math.abs(a.p) < 0.01 and math.abs(a.y) < 0.01 and math.abs(a.r) < 0.01 then
        return pos, ang
    end

    local newang = Angle(ang.p, ang.y, ang.r)
    newang:RotateAroundAxis(newang:Right(), a.p)
    newang:RotateAroundAxis(newang:Up(), a.y)
    newang:RotateAroundAxis(newang:Forward(), a.r)

    local right, forward, up = newang:Right(), newang:Forward(), newang:Up()
    pos = pos + right * p.x + forward * p.y + up * p.z

    return pos, newang
end

-- ==============================
-- WORLDMODEL / THIRD PERSON OFFSET
-- ==============================
-- ARC9 poses the held world model by writing wm.slottbl.Pos/Ang every time
-- SWEP:ShouldTPIK() runs (see cl_tpik.lua -> SetTPIKOffset). Those offsets live in
-- the right hand bone's space. We add the blindfire pose on top of whatever ARC9
-- just computed, so the gun moves and TPIK drags the arms along with it.

local function applyWorldModelOffset(wep)
    if not IsValid(wep) or not wep.CanBlindFire then return end
    if not wmEnable:GetBool() then return end

    local owner = wep:GetOwner()
    if not IsValid(owner) then return end
    if owner ~= LocalPlayer() and not wmOthers:GetBool() then return end

    local wm = wep.GetWM and wep:GetWM()
    if not IsValid(wm) or not wm.slottbl then return end

    local active = wep.BlindFiring and not ShouldDisableScoped(wep)

    -- ShouldTPIK runs several times per frame (cl_model.lua asks it too), so only
    -- advance the smoothing once per frame or the transition speed becomes fps-dependent
    local frame = FrameNumber()
    if wep._BF_WMFrame ~= frame then
        wep._BF_WMFrame = frame
        wep._BF_WMSmoothPos = wep._BF_WMSmoothPos or Vector(0, 0, 0)
        wep._BF_WMSmoothAng = wep._BF_WMSmoothAng or Angle(0, 0, 0)

        local targetPos = active and getWMPosOffset(wep) or vector_origin
        local targetAng = active and getWMAngOffset(wep) or angle_zero

        local frac = math.Clamp(FrameTime() * smoothSpeed:GetFloat(), 0, 1)
        wep._BF_WMSmoothPos = LerpVector(frac, wep._BF_WMSmoothPos, targetPos)
        wep._BF_WMSmoothAng = LerpAngle(frac, wep._BF_WMSmoothAng, targetAng)
    end

    local p = wep._BF_WMSmoothPos
    local a = wep._BF_WMSmoothAng
    if not p or not a then return end

    if not active and p:LengthSqr() < 0.0001
        and math.abs(a.p) < 0.01 and math.abs(a.y) < 0.01 and math.abs(a.r) < 0.01 then
        return
    end

    -- never mutate in place: when TPIK is off, slottbl.Pos IS the SWEP's WorldModelOffset.Pos
    wm.slottbl.Pos = (wm.slottbl.Pos or vector_origin) + p
    wm.slottbl.Ang = (wm.slottbl.Ang or angle_zero) + a
end

if CLIENT then
    -- arc9_bf_debug: prints every gate the third person pose has to pass, so a
    -- failure says which one instead of "it does not work"
    concommand.Add("arc9_bf_debug", function()
        local ply = LocalPlayer()
        local wep = IsValid(ply) and ply:GetActiveWeapon()

        local function say(k, v) print(string.format("  %-22s %s", k, tostring(v))) end

        print("=== ARC9 Blindfire third person ===")
        if not IsValid(wep) then print("  no weapon") return end

        say("weapon", wep:GetClass())
        say("ARC9", wep.ARC9)
        say("CanBlindFire", wep.CanBlindFire)
        say("TPIK wrapper installed", wep._BF_TPIKWrapped)
        say("arc9_tpik", GetConVar("arc9_tpik") and GetConVar("arc9_tpik"):GetBool())
        say("arc9_bf_worldmodel", wmEnable:GetBool())
        say("MirrorVMWM", wep.MirrorVMWM)
        say("WorldModelOffset", wep.WorldModelOffset ~= nil)
        say("NoTPIK", wep.NoTPIK)
        say("ShouldTPIK()", wep.ShouldTPIK and wep:ShouldTPIK())
        say("ShouldLOD()", wep.ShouldLOD and wep:ShouldLOD())

        local wm = wep.GetWM and wep:GetWM()
        say("world model valid", IsValid(wm))
        say("wm.slottbl", IsValid(wm) and wm.slottbl ~= nil)
        if IsValid(wm) and wm.slottbl then
            say("wm.slottbl.Pos", wm.slottbl.Pos)
            say("wm.slottbl.Ang", wm.slottbl.Ang)
        end

        say("BlindFiring", wep.BlindFiring)
        say("BlindFireDirection", wep.BlindFireDirection)
        say("scoped-disable", ShouldDisableScoped(wep))
        say("smoothed WM pos", wep._BF_WMSmoothPos)
        say("smoothed WM ang", wep._BF_WMSmoothAng)
        say("ShouldDrawLocalPlayer", ply:ShouldDrawLocalPlayer())
    end)
end

-- ==============================
-- WEAPON PATCHING
-- ==============================
local function installWeaponPatch(wep)
    if not IsValid(wep) or not wep.ARC9 then return end

    if not wep._BF_OriginalDoProjectileAttack and wep.DoProjectileAttack then
        wep._BF_OriginalDoProjectileAttack = wep.DoProjectileAttack
    end

    if wep._BF_OriginalDoProjectileAttack and not wep._BF_DoProjectileAttackWrapped then
        local original = wep._BF_OriginalDoProjectileAttack
        wep.DoProjectileAttack = function(self, pos, ang, spread, ...)
            pos, ang = applyShotOrigin(self, pos, ang)
            return original(self, pos, ang, spread, ...)
        end
        wep._BF_DoProjectileAttackWrapped = true
    end

    if CLIENT and wep.CanBlindFire and wep.ShouldTPIK and not wep._BF_TPIKWrapped then
        local original = wep.ShouldTPIK
        wep.ShouldTPIK = function(self)
            local should = original(self)
            if should then applyWorldModelOffset(self) end
            return should
        end
        wep._BF_TPIKWrapped = true
    end

    if CLIENT and wep.GetViewModelPosition and not wep._BF_ViewModelWrapped then
        local original = wep.GetViewModelPosition
        wep.GetViewModelPosition = function(self, pos, ang)
            local inputPos = pos and Vector(pos)
            local inputAng = ang and Angle(ang)
            pos, ang = original(self, pos, ang)
            if self.CanBlindFire then
                pos, ang = applyViewModelOffset(self, pos, ang)
            end
            if muzzleTestActive and pos and ang then
                local pivot = pos + ang:Forward() * 24
                ang = Angle(ang)
                ang:RotateAroundAxis(ang:Right(), muzzleTestAimAng.p)
                ang:RotateAroundAxis(ang:Up(), muzzleTestAimAng.y)
                pos = pivot - ang:Forward() * 24
            end
            if inputPos and inputAng and pos and ang then
                self._BF_ViewModelInputPos = inputPos
                self._BF_ViewModelInputAng = inputAng
                self._BF_ViewModelRenderPos = Vector(pos)
                self._BF_ViewModelRenderAng = Angle(ang)
                self._BF_ViewModelRenderFrame = FrameNumber()
            end
            return pos, ang
        end
        wep._BF_ViewModelWrapped = true
    end

    -- ARC9 Tactical Deadzone wraps GetViewModelPosition after our patch and
    -- rotates the returned pose around the eye. Capture that outer result too;
    -- otherwise the ADS pose delta is measured from our inner pose and the
    -- deadzone rotation gets applied a second time to the muzzle attachment.
    if CLIENT and wep.DZ_Wrapped and wep._BF_ViewModelWrapped
        and wep.GetViewModelPosition and not wep._BF_ViewModelPostDeadzoneWrapped then
        local original = wep.GetViewModelPosition
        wep.GetViewModelPosition = function(self, pos, ang)
            pos, ang = original(self, pos, ang)
            if pos and ang then
                self._BF_ViewModelRenderPos = Vector(pos)
                self._BF_ViewModelRenderAng = Angle(ang)
                self._BF_ViewModelRenderFrame = FrameNumber()
            end
            return pos, ang
        end
        wep._BF_ViewModelPostDeadzoneWrapped = true
    end
end

local function resetIfNotARC9(wep)
    if not IsValid(wep) then return end
    if not wep.ARC9 then return end
    installWeaponPatch(wep)
end

hook.Add("Think", "ARC9_BlindFire_RuntimePatch", function()
    if CLIENT then
        -- other players need the patch too, otherwise their world models never pose
        for _, p in ipairs(player.GetAll()) do
            resetIfNotARC9(p:GetActiveWeapon())
        end
    else
        for _, p in ipairs(player.GetAll()) do
            resetIfNotARC9(p:GetActiveWeapon())
        end
    end
end)

-- ==============================
-- NETWORK SYNC
-- ==============================
if SERVER then
    net.Receive("ARC9_BlindFire_State", function(_, ply)
        local wep = ply:GetActiveWeapon()
        if not IsValid(wep) or not wep.CanBlindFire then return end

        local bf = net.ReadBool()
        local dir = math.Clamp(net.ReadInt(3), -1, 1)
        local px = math.Clamp(net.ReadFloat(), -100, 100)
        local py = math.Clamp(net.ReadFloat(), -100, 100)
        local pz = math.Clamp(net.ReadFloat(), -100, 100)
        local ap = math.Clamp(net.ReadFloat(), -90, 90)
        local ay = math.Clamp(net.ReadFloat(), -90, 90)
        local ar = math.Clamp(net.ReadFloat(), -90, 90)

        if dir < 0 and wep.BlindFireLeft == false then return end
        if dir > 0 and wep.BlindFireRight == false then return end

        local newdir = bf and dir or 0
        local changed = (wep.BlindFiring ~= bf) or (wep.BlindFireDirection ~= newdir)

        wep.BlindFiring = bf
        wep.BlindFireDirection = newdir
        wep.BlindFireOffsetPos = bf and Vector(px, py, pz) or Vector(0, 0, 0)
        wep.BlindFireAimOffsetAng = bf and Angle(ap, ay, ar) or Angle(0, 0, 0)
        installWeaponPatch(wep)

        -- tell everyone else, so they can pose this player's world model
        if changed then
            net.Start("ARC9_BlindFire_Sync")
            net.WriteEntity(ply)
            net.WriteBool(bf)
            net.WriteInt(newdir, 3)
            net.SendPVS(ply:GetPos())
        end
    end)

    net.Receive("ARC9_Muzzle_Target", function(_, ply)
        local wep = ply:GetActiveWeapon()
        if not IsValid(wep) or not wep.ARC9 then return end

        local hasTarget = net.ReadBool()
        if not hasTarget then
            wep.MuzzleTargetPos = nil
            wep.MuzzleOriginPos = nil
            wep.MuzzleDirection = nil
            return
        end

        local ox = net.ReadFloat()
        local oy = net.ReadFloat()
        local oz = net.ReadFloat()
        local dx = net.ReadFloat()
        local dy = net.ReadFloat()
        local dz = net.ReadFloat()

        wep.MuzzleOriginPos = Vector(ox, oy, oz)
        wep.MuzzleDirection = Vector(dx, dy, dz):GetNormalized()
    end)
end

-- ==============================
-- CLIENT: MUZZLE TRACE & RENDER
-- ==============================
if CLIENT then
    -- other players' blindfire state, for their world models
    net.Receive("ARC9_BlindFire_Sync", function()
        local ply = net.ReadEntity()
        local bf = net.ReadBool()
        local dir = net.ReadInt(3)

        if not IsValid(ply) or ply == LocalPlayer() then return end -- we own our own state

        local wep = ply:GetActiveWeapon()
        if not IsValid(wep) or not wep.CanBlindFire then return end

        wep.BlindFiring = bf
        wep.BlindFireDirection = bf and dir or 0
        installWeaponPatch(wep)
    end)

    hook.Add("CreateMove", "ARC9_Muzzle_Mouse3TestAim", function(cmd)
        local ply = LocalPlayer()
        local wep = IsValid(ply) and ply:GetActiveWeapon()
        local holding = muzzleMouseTest:GetBool()
            and input.IsMouseDown(MOUSE_MIDDLE)
            and IsValid(wep) and wep.ARC9
            and not ply:ShouldDrawLocalPlayer()

        if not holding then
            if muzzleTestActive then
                muzzleTestActive = false
                muzzleTestCameraAng = nil
                muzzleTestAimAng = Angle(0, 0, 0)
            end
            return
        end

        if not muzzleTestActive then
            muzzleTestActive = true
            muzzleTestCameraAng = Angle(ply:EyeAngles())
            muzzleTestAimAng = Angle(0, 0, 0)
        end

        local yawScale = GetConVar("m_yaw")
        local pitchScale = GetConVar("m_pitch")
        muzzleTestAimAng.y = muzzleTestAimAng.y - cmd:GetMouseX() * (yawScale and yawScale:GetFloat() or 0.022)
        muzzleTestAimAng.p = math.Clamp(
            muzzleTestAimAng.p - cmd:GetMouseY() * (pitchScale and pitchScale:GetFloat() or 0.022),
            -89, 89
        )

        if muzzleTestCameraAng then
            cmd:SetViewAngles(muzzleTestCameraAng)
        end
    end)
    -- Keep references because CalcViewModelView lagger hooks mutate these pose
    -- objects in place. PostDrawViewModel snapshots them after rendering.
    hook.Add("CalcViewModelView", "ARC9_Muzzle_CaptureViewModelPose", function(wep, vm, oldPos, oldAng, pos, ang)
        local ply = LocalPlayer()
        if not IsValid(ply) or wep ~= ply:GetActiveWeapon() or not wep.ARC9 then return end
        if not IsValid(vm) or vm ~= ply:GetViewModel() or not pos or not ang then return end

        -- GetViewModelPosition runs before CalcViewModelView. Use its cached
        -- output as the base so hook ordering cannot turn the lagger delta into
        -- an identity transform when this callback runs after the lagger.
        local basePos = wep._BF_ViewModelRenderPos or pos
        local baseAng = wep._BF_ViewModelRenderAng or ang
        wep._BF_PendingViewModelPose = {
            basePos = Vector(basePos),
            baseAng = Angle(baseAng),
            renderPosRef = pos,
            renderAngRef = ang,
            frame = FrameNumber(),
        }
    end)
    local lastStart, lastEnd, lastDir

    -- Update after the viewmodel has been drawn so attachment transforms include
    -- clientside laggers and barrel-pivoting viewmodel mods.
    local function updateMuzzleTrace()
        local ply = LocalPlayer()
        if not IsValid(ply) then return end
        local wep = ply:GetActiveWeapon()
        if not IsValid(wep) or not wep.ARC9 then return end
        if not laserEnable:GetBool() then return end

        -- TrueFP: траектория из дула работает и в оптике (режим scope отключает только blindfire)

        local attach = getMuzzleAttachment(wep)
        if attach then attach = applyAimedLaggerPose(wep, attach) end
        if attach then attach = applyViewModelFOVToMuzzle(wep, attach) end
        if not attach then
            if wep._ML_LastSentDirection then
                wep._ML_LastSentOrigin = nil
                wep._ML_LastSentDirection = nil
                wep.MuzzleTargetPos = nil
                wep.MuzzleOriginPos = nil
                wep.MuzzleDirection = nil
                net.Start("ARC9_Muzzle_Target")
                net.WriteBool(false)
                net.SendToServer()
            end
            return
        end

        local pos = Vector(attach.Pos)
        local ang = Angle(attach.Ang)
        local boreDirection = ang:Forward()


        if wep.BlindFiring then
            local laserOff = getLaserOffset(wep)
            if laserOff:LengthSqr() > 0 then
                pos = pos + ang:Right() * laserOff.x + ang:Forward() * laserOff.y + ang:Up() * laserOff.z
            end
        end

        wep.MuzzleOriginPos = pos
        wep.MuzzleDirection = boreDirection
        wep._BF_TraceOrigin = pos
        wep._BF_TraceAng = ang

        local tr = util.TraceLine({
            start = pos,
            endpos = pos + boreDirection * 8192,
            filter = ply,
            mask = MASK_SHOT,
        })
        local target = tr.HitPos

        lastStart = attach.VisualPos or pos
        lastEnd = target
        lastDir = boreDirection

        wep.MuzzleTargetPos = target

        -- the trace above runs every frame, so the laser and our own aim are always
        -- current. Only the trip to the server is rate limited.
        local now = CurTime()
        local interval = 1 / math.Clamp(muzzleRate:GetFloat(), 1, 120)
        if wep._ML_LastSend and now - wep._ML_LastSend < interval then return end

        local dir = boreDirection
        local oldDir = wep._ML_LastSentDirection
        local originChanged = not wep._ML_LastSentOrigin
            or (pos - wep._ML_LastSentOrigin):LengthSqr() > 0.25
        local directionChanged = not oldDir or oldDir:Dot(dir) < 0.999999

        if originChanged or directionChanged then
            wep._ML_LastSend = now
            wep._ML_LastSentOrigin = Vector(pos)
            wep._ML_LastSentDirection = Vector(dir)
            net.Start("ARC9_Muzzle_Target")
            net.WriteBool(true)
            net.WriteFloat(pos.x); net.WriteFloat(pos.y); net.WriteFloat(pos.z)
            net.WriteFloat(dir.x); net.WriteFloat(dir.y); net.WriteFloat(dir.z)
            net.SendToServer()
        end
    end

    -- Keep Think as a fallback for third person, where the local viewmodel may
    -- not be drawn. PostDrawViewModel supplies the final first-person transform.
    hook.Add("Think", "ARC9_MuzzleLaser_Trace", updateMuzzleTrace)
    -- TrueFP: viewmodel скрыт, PostDrawViewModel не вызывается; дуло берётся с worldmodel
    -- уже ПОСЛЕ его отрисовки в этом кадре (точная поза с учётом свэя, отдачи, freeaim)
    hook.Add("PostDrawOpaqueRenderables", "ARC9_MuzzleLaser_PostWM", function(bDepth, bSky, b3DSky)
        if bDepth or bSky or b3DSky then return end
        if ARC9 and ARC9.OverDraw then return end
        local ply = LocalPlayer()
        if IsValid(ply) and ply:ShouldDrawLocalPlayer() then updateMuzzleTrace() end
    end)
    hook.Add("PostDrawViewModel", "ARC9_MuzzleLaser_PostDrawTrace", function(vm, weapon, ply)
        -- GMod passes (viewmodel, weapon, player); keep this restricted to our
        -- own first-person viewmodel so remote players cannot overwrite the trace.
        if ply ~= LocalPlayer() or not IsValid(weapon) or not weapon.ARC9 then return end
        if not IsValid(vm) or vm ~= ply:GetViewModel() then return end
        if weapon:GetOwner() ~= ply then return end
        local pending = weapon._BF_PendingViewModelPose
        if pending and pending.frame == FrameNumber() then
            weapon._BF_FinalViewModelPose = {
                basePos = pending.basePos,
                baseAng = pending.baseAng,
                renderPos = Vector(pending.renderPosRef),
                renderAng = Angle(pending.renderAngRef),
                frame = pending.frame,
            }
        end
        updateMuzzleTrace()
    end)

    -- ==============================
    -- RENDER LASER
    -- ==============================
    hook.Add("PostDrawOpaqueRenderables", "ARC9_MuzzleLaser_Draw", function()
        local ply = LocalPlayer()
        if not IsValid(ply) then return end
        local wep = ply:GetActiveWeapon()
        if not IsValid(wep) or not wep.ARC9 then return end

        local drawLaser = laserVisible:GetBool() and lastStart and lastEnd
        if not drawLaser then return end

        render.SetMaterial(Material("vgui/white"))

        if drawLaser then
            render.DrawLine(lastStart, lastEnd, Color(255, 0, 0), true)

            if lastDir then
                local dirEnd = lastStart + lastDir * 100
                render.DrawLine(lastStart, dirEnd, Color(0, 255, 0), true)
            end

            local size = 4
            render.DrawLine(lastEnd - Vector(size,0,0), lastEnd + Vector(size,0,0), Color(255, 255, 0), true)
            render.DrawLine(lastEnd - Vector(0,size,0), lastEnd + Vector(0,size,0), Color(255, 255, 0), true)
            render.DrawLine(lastEnd - Vector(0,0,size), lastEnd + Vector(0,0,size), Color(255, 255, 0), true)

        end

    end)

    -- ==============================
    -- BLINDFIRE INPUT
    -- ==============================
    local wasA, wasW, wasD, wasS = false, false, false, false

    hook.Add("Think", "ARC9_BlindFire_Input", function()
        local ply = LocalPlayer()
        if not IsValid(ply) then return end
        local wep = ply:GetActiveWeapon()
        local wepValid = IsValid(wep) and wep.CanBlindFire

        local alt = input.IsKeyDown(KEY_RALT)   -- TrueFP: левый Alt занят freelook
        local aDown = input.IsKeyDown(KEY_A)
        local wDown = input.IsKeyDown(KEY_W)
        local dDown = input.IsKeyDown(KEY_D)
        local sDown = input.IsKeyDown(KEY_S)

        local aPressed = alt and aDown and not wasA
        local wPressed = alt and wDown and not wasW
        local dPressed = alt and dDown and not wasD
        local sPressed = alt and sDown and not wasS
        wasA, wasW, wasD, wasS = aDown, wDown, dDown, sDown

        if not wepValid then return end
        if wep.GetCustomize and wep:GetCustomize() then return end

        local function sendState(active, dir, pos, aim)
            net.Start("ARC9_BlindFire_State")
            net.WriteBool(active)
            net.WriteInt(active and dir or 0, 3)
            if active then
                net.WriteFloat(pos.x); net.WriteFloat(pos.y); net.WriteFloat(pos.z)
                net.WriteFloat(aim.p); net.WriteFloat(aim.y); net.WriteFloat(aim.r)
            else
                for _ = 1, 3 do net.WriteFloat(0) end
                for _ = 1, 3 do net.WriteFloat(0) end
            end
            net.SendToServer()
        end

        local function turnOff()
            wep.BlindFiring = false
            wep.BlindFireDirection = 0
            wep.BlindFireOffsetPos = Vector(0,0,0)
            wep.BlindFireAimOffsetAng = Angle(0,0,0)
            sendState(false, 0, nil, nil)
        end

        local function turnOn(dir)
            if dir == 0 and wep.BlindFireStraight == false then return end
            if dir < 0 and wep.BlindFireLeft == false then return end
            if dir > 0 and wep.BlindFireRight == false then return end
            wep.BlindFiring = true
            wep.BlindFireDirection = dir
            local pos = getPosOffset(wep)
            wep.BlindFireOffsetPos = pos
            wep.BlindFireAimOffsetAng = Angle(0,0,0)
            sendState(true, dir, pos, Angle(0,0,0))
        end

        -- Scope override: if scoped and should be disabled, force off and block
        if ShouldDisableScoped(wep) then
            if wep.BlindFiring then turnOff() end
            -- Skip all key handling when scoped
            return
        end

        if wep.BlindFiring and ply:KeyDown(IN_ATTACK2) then turnOff() return end

        if sPressed then
            if wep.BlindFiring then turnOff() end
            return
        end

        if wPressed then
            if wep.BlindFireStraight == false then
                -- disabled
            elseif wep.BlindFiring and wep.BlindFireDirection == 0 then turnOff() else turnOn(0) end
        elseif aPressed then
            if wep.BlindFiring and wep.BlindFireDirection == -1 then turnOff() else turnOn(-1) end
        elseif dPressed then
            if wep.BlindFiring and wep.BlindFireDirection == 1 then turnOff() else turnOn(1) end
        end

        if wep.BlindFiring then
            local pos = getPosOffset(wep)
            local old = wep.BlindFireOffsetPos
            if not old or (pos - old):LengthSqr() > 0.0001 then
                wep.BlindFireOffsetPos = pos
                sendState(true, wep.BlindFireDirection, pos, wep.BlindFireAimOffsetAng)
            end
        end
    end)
end
