-- ============================================================================
-- TrueFP Bodycam: параметры движения игрока (общий файл: сервер + предсказание клиента)
--  - скорость ходьбы и бега
--  - инерция (дольше разгон и торможение)
--  - пауза между прыжками (после приземления)
-- Значения берутся из настроек самого игрока (userinfo): truefp_mv_walk / mv_run / mv_inertia / mv_jumpcd.
-- Сервер разрешает это командой sv_truefp_move_allowed (в одиночной игре включено по умолчанию).
-- ============================================================================
if SERVER then AddCSLuaFile() end

local allowed = CreateConVar("sv_truefp_move_allowed", game.SinglePlayer() and "1" or "0",
    bit.bor(FCVAR_ARCHIVE, FCVAR_REPLICATED, FCVAR_NOTIFY),
    "1 = игроки могут менять свою скорость, инерцию и паузу между прыжками через настройки TrueFP")

local function Num(ply, name, lo, hi)
    local v
    if CLIENT then
        local c = GetConVar(name)
        v = c and c:GetFloat() or 0
    else
        v = ply:GetInfoNum(name, 0)
    end
    return math.Clamp(v, lo, hi)
end

local function Cfg(ply)
    if not allowed:GetBool() then return nil end
    if CLIENT and ply ~= LocalPlayer() then return nil end
    if not IsValid(ply) or not ply:Alive() then return nil end
    -- главный выключатель игрока (userinfo): truefp_move_enable
    if CLIENT then
        local m = GetConVar("truefp_move_enable")
        if m and not m:GetBool() then return nil end
    else
        if ply:GetInfoNum("truefp_move_enable", 1) == 0 then return nil end
    end
    return {
        walk = Num(ply, "truefp_mv_walk", 0, 500),
        run = Num(ply, "truefp_mv_run", 0, 800),
        inertia = Num(ply, "truefp_mv_inertia", 0, 10),
        jumpcd = Num(ply, "truefp_mv_jumpcd", 0, 5),
    }
end

hook.Add("SetupMove", "TFPBC_Move_Setup", function(ply, mv, cmd)
    local c = Cfg(ply)
    if not c then return end
    ply.TFPBC_PrevVel = mv:GetVelocity()
    if c.walk > 0 or c.run > 0 then
        local walk = c.walk > 0 and c.walk or ply:GetWalkSpeed()
        local run = c.run > 0 and c.run or ply:GetRunSpeed()
        local sp = mv:KeyDown(IN_SPEED) and run or walk
        if ply:Crouching() then sp = sp * ply:GetCrouchedWalkSpeed() end
        mv:SetMaxSpeed(sp)
        mv:SetMaxClientSpeed(sp)
    end
end)

-- инерция: скорость по земле догоняет «то, что насчитал движок», с задержкой
hook.Add("FinishMove", "TFPBC_Move_Inertia", function(ply, mv)
    local c = Cfg(ply)
    if not c or c.inertia <= 0 then return end
    local pv = ply.TFPBC_PrevVel
    if not pv or not ply:OnGround() or ply:GetMoveType() ~= MOVETYPE_WALK then return end
    local v = mv:GetVelocity()
    local response = 24 / (1 + c.inertia * 2.5)
    local a = 1 - math.exp(-response * FrameTime())
    mv:SetVelocity(Vector(Lerp(a, pv.x, v.x), Lerp(a, pv.y, v.y), v.z))
end)

-- пауза между прыжками считается от приземления
hook.Add("OnPlayerHitGround", "TFPBC_Move_Land", function(ply)
    local c = Cfg(ply)
    if not c or c.jumpcd <= 0 then return end
    ply.TFPBC_NextJump = CurTime() + c.jumpcd
end)

hook.Add("StartCommand", "TFPBC_Move_Jump", function(ply, cmd)
    if not cmd:KeyDown(IN_JUMP) then return end
    local nj = ply.TFPBC_NextJump
    if nj and nj > CurTime() then
        local c = Cfg(ply)
        if c and c.jumpcd > 0 then cmd:RemoveKey(IN_JUMP) end
    end
end)
